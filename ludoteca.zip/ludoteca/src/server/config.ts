import path from 'node:path';
import fs from 'node:fs';

const root = path.resolve(import.meta.dirname, '..', '..');

// Carrega .env da raiz do projeto, se existir (as variáveis ficam só no servidor).
const envFile = path.join(root, '.env');
if (fs.existsSync(envFile) && !process.env.LUDOTECA_SKIP_ENV_FILE) {
  try { process.loadEnvFile(envFile); } catch { /* ignora .env inválido */ }
}

function num(v: string | undefined, d: number): number {
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? n : d;
}

export interface Config {
  root: string;
  port: number;
  host: string;
  dataDir: string;
  dbPath: string;
  bggToken: string | null;
  bggBaseUrl: string;
  bggMinIntervalMs: number;
  bggCacheTtlHours: number;
  downloadImages: boolean;
  anthropicApiKey: string | null;
  visionModel: string;
  visionProvider: 'auto' | 'anthropic' | 'ocr' | 'none';
  seedCollection: boolean;
}

export function loadConfig(overrides: Partial<Config> = {}): Config {
  const dataDir = path.resolve(root, process.env.DATA_DIR || 'data');
  const cfg: Config = {
    root,
    port: num(process.env.PORT, 5174),
    host: process.env.HOST || '127.0.0.1',
    dataDir,
    dbPath: process.env.DB_PATH ? path.resolve(root, process.env.DB_PATH) : path.join(dataDir, 'ludoteca.db'),
    bggToken: process.env.BGG_API_TOKEN?.trim() || null,
    bggBaseUrl: (process.env.BGG_BASE_URL || 'https://boardgamegeek.com').replace(/\/$/, ''),
    bggMinIntervalMs: num(process.env.BGG_MIN_INTERVAL_MS, 2500),
    bggCacheTtlHours: num(process.env.BGG_CACHE_TTL_HOURS, 24 * 7),
    downloadImages: process.env.DOWNLOAD_IMAGES !== '0',
    anthropicApiKey: process.env.ANTHROPIC_API_KEY?.trim() || null,
    visionModel: process.env.VISION_MODEL || 'claude-sonnet-5-5',
    visionProvider: (process.env.VISION_PROVIDER as Config['visionProvider']) || 'auto',
    seedCollection: process.env.SEED_COLLECTION !== '0',
    ...overrides,
  };
  return cfg;
}
