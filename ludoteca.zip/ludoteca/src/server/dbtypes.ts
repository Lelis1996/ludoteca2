/** Subconjunto da API do better-sqlite3 usado pela aplicação (implementado também sobre sql.js no celular). */
export interface RunResult { changes: number; lastInsertRowid: number | bigint }
export interface Statement {
  run(...params: unknown[]): RunResult;
  get(...params: unknown[]): unknown;
  all(...params: unknown[]): unknown[];
}
export interface DB {
  prepare(sql: string): Statement;
  exec(sql: string): unknown;
  transaction<F extends (...args: any[]) => any>(fn: F): F;
  close(): void;
}
