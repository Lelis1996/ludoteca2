import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import type { DB } from './dbtypes';
import { migrate, seedBasics } from './core';

export type { DB } from './dbtypes';
export { SEED_TAGS, migrate } from './core';

export type NodeDB = Database.Database;

/** Abre o banco SQLite no computador (servidor). */
export function openDb(file: string): DB & { raw: NodeDB } {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const raw = new Database(file);
  raw.pragma('journal_mode = WAL');
  raw.pragma('foreign_keys = ON');
  raw.pragma('busy_timeout = 5000');
  const db = raw as unknown as DB & { raw: NodeDB };
  Object.defineProperty(db, 'raw', { value: raw, enumerable: false });
  migrate(db);
  seedBasics(db);
  return db;
}

export function nowIso(): string {
  return new Date().toISOString();
}
