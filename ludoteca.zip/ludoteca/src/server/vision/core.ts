// Reconhecimento de caixas: tipos e lógica comuns ao computador e ao celular.

export interface DetectedBox {
  title: string;
  text?: string;
  isExpansion?: boolean;
  baseGame?: string | null;
  publisher?: string | null;
  edition?: string | null;
  language?: string | null;
  confidence: number;          // 0..1
  bbox?: [number, number, number, number] | null; // x, y, w, h normalizados 0..1
  notes?: string | null;
}

export interface VisionProvider {
  name: 'anthropic' | 'ocr' | 'fake';
  label: string;
  analyze(image: Uint8Array): Promise<{ boxes: DetectedBox[]; raw: unknown }>;
}

export const PROMPT = `You are helping catalogue a personal board game collection. Identify every board game box (front covers, spines on shelves, stacked boxes) visible in this photo.

Rules:
- Report only titles you can actually read or recognise with reasonable confidence. Do not guess titles of boxes you cannot read; skip them.
- Titles may be in English or Brazilian Portuguese. Report the title exactly as printed on the box in "title"; if you also know the original English title, put it in "english_title".
- If the box is an expansion (e.g. "Expansão", "Expansion", a subtitle under a known game's logo), set "is_expansion": true and give the base game in "base_game".
- If the box could be a specific edition (e.g. "2nd edition", "Big Box", a Portuguese edition by Galápagos/Devir/Grok/Meeple BR), mention it in "edition". If you are unsure which edition, say so in "notes".
- "confidence" is 0.0–1.0 for how sure you are of the title reading.
- "bbox" is the box's approximate bounding box as [x, y, width, height], each a fraction 0–1 of the image size.

Answer with JSON only, no prose, in this shape:
{"games":[{"title":"","english_title":null,"is_expansion":false,"base_game":null,"publisher":null,"edition":null,"language":"en|pt|other","confidence":0.0,"bbox":[0,0,0,0],"notes":null}]}`;

function clamp01(n: unknown): number {
  const v = Number(n);
  return Number.isFinite(v) ? Math.min(1, Math.max(0, v)) : 0;
}

export function parseVisionJson(text: string): DetectedBox[] {
  const start = text.indexOf('{');
  const end = text.lastIndexOf('}');
  if (start < 0 || end < start) throw new Error('A resposta do serviço de visão não contém JSON.');
  const data = JSON.parse(text.slice(start, end + 1));
  const games: any[] = Array.isArray(data.games) ? data.games : [];
  return games
    .filter((g) => typeof g?.title === 'string' && g.title.trim())
    .map((g) => {
      const bb = Array.isArray(g.bbox) && g.bbox.length === 4 ? g.bbox.map(clamp01) as [number, number, number, number] : null;
      const english = typeof g.english_title === 'string' && g.english_title.trim() ? g.english_title.trim() : null;
      return {
        title: english ?? g.title.trim(),
        text: g.title.trim(),
        isExpansion: !!g.is_expansion,
        baseGame: g.base_game ?? null,
        publisher: g.publisher ?? null,
        edition: g.edition ?? null,
        language: g.language ?? null,
        confidence: clamp01(g.confidence ?? 0.5),
        bbox: bb && bb[2] > 0 && bb[3] > 0 ? bb : null,
        notes: [english && english !== g.title.trim() ? `Título na caixa: "${g.title.trim()}"` : null, g.notes].filter(Boolean).join(' · ') || null,
      };
    });
}

/** Operações de imagem que cada plataforma fornece (sharp no computador, canvas no celular). */
export interface VisionImageOps {
  /** JPEG reduzido (lado maior ≤ maxSide), em base64 */
  jpegBase64(image: Uint8Array, maxSide: number): Promise<string>;
  /** Prepara a imagem para OCR: dimensões e versões giradas em tons de cinza */
  forOcr(image: Uint8Array, maxSide: number): Promise<{ width: number; height: number; rotated(deg: 0 | 90 | 270): Promise<unknown> }>;
}

/** Visão via API da Anthropic (Claude). */
export class AnthropicVision implements VisionProvider {
  name = 'anthropic' as const;
  label: string;
  constructor(private apiKey: string, private model: string, private ops: VisionImageOps, private fetchImpl: typeof fetch = fetch, private browser = false) {
    this.label = `Claude (${model})`;
  }
  async analyze(image: Uint8Array) {
    const data = await this.ops.jpegBase64(image, 1568);
    const headers: Record<string, string> = { 'x-api-key': this.apiKey, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' };
    if (this.browser) headers['anthropic-dangerous-direct-browser-access'] = 'true';
    const res = await this.fetchImpl('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers,
      body: JSON.stringify({
        model: this.model,
        max_tokens: 4000,
        messages: [{
          role: 'user',
          content: [
            { type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data } },
            { type: 'text', text: PROMPT },
          ],
        }],
      }),
      signal: AbortSignal.timeout(120000),
    });
    const body: any = await res.json().catch(() => null);
    if (!res.ok) throw new Error(`Serviço de visão respondeu HTTP ${res.status}: ${body?.error?.message ?? 'erro desconhecido'}`);
    const text = (body?.content ?? []).filter((c: any) => c.type === 'text').map((c: any) => c.text).join('\n');
    return { boxes: parseVisionJson(text), raw: { model: body?.model, text } };
  }
}

/** Worker do tesseract.js (mesma API no Node e no navegador). */
export interface OcrWorker {
  setParameters(p: Record<string, unknown>): Promise<unknown>;
  recognize(image: any, opts?: unknown, output?: unknown): Promise<any>;
  terminate(): Promise<unknown>;
}

/** OCR local (Tesseract, inglês + português), sem serviços externos. Menos preciso; exige revisão. */
export class OcrVision implements VisionProvider {
  name = 'ocr' as const;
  label = 'OCR local (Tesseract)';
  private worker: Promise<OcrWorker> | null = null;
  constructor(private ops: VisionImageOps, private createWorker: () => Promise<OcrWorker>) {}

  private getWorker() {
    if (!this.worker) {
      this.worker = (async () => {
        const w = await this.createWorker();
        // "texto esparso": acha títulos espalhados pela foto
        await w.setParameters({ tessedit_pageseg_mode: '11' });
        return w;
      })();
      this.worker.catch(() => { this.worker = null; });
    }
    return this.worker;
  }

  async close() {
    if (this.worker) { const w = await this.worker; await w.terminate(); this.worker = null; }
  }

  async analyze(image: Uint8Array) {
    const prep = await this.ops.forOcr(image, 2200);
    const W = prep.width, H = prep.height;
    const worker = await this.getWorker();
    type Line = { text: string; conf: number; x0: number; y0: number; x1: number; y1: number; size: number; rot: number };
    const lines: Line[] = [];
    // 0°, 90° e 270° (lombadas costumam estar giradas) × limiarização global e adaptativa
    // (a adaptativa acha texto claro sobre fundo escuro; a global, texto encostado em bordas)
    for (const rot of [0, 90, 270] as const) {
      const img = await prep.rotated(rot);
      for (const thresholding of ['0', '1']) {
        await worker.setParameters({ thresholding_method: thresholding });
        const r = await worker.recognize(img, {}, { blocks: true });
        for (const b of r.data.blocks ?? []) for (const p of b.paragraphs ?? []) for (const l of p.lines ?? []) {
          const text = String(l.text).replace(/\s+/g, ' ').trim();
          const letters = (text.match(/[\p{L}]/gu) ?? []).length;
          if (l.confidence < 55 || letters < 3 || letters / Math.max(1, text.length) < 0.6) continue;
          const { x0, y0, x1, y1 } = l.bbox;
          // volta as coordenadas para a imagem original
          const pts = [[x0, y0], [x1, y1]].map(([x, y]) => rot === 0 ? [x, y] : rot === 90 ? [y, H - 1 - x] : [W - 1 - y, x]);
          const xs = pts.map((q) => q[0]), ys = pts.map((q) => q[1]);
          lines.push({ text, conf: l.confidence / 100, x0: Math.min(...xs), y0: Math.min(...ys), x1: Math.max(...xs), y1: Math.max(...ys), size: y1 - y0, rot });
        }
      }
    }
    // texto maior primeiro (títulos costumam ser o maior texto da caixa)
    lines.sort((a, b) => b.size - a.size);
    const seen = new Set<string>();
    const boxes: DetectedBox[] = [];
    for (const l of lines) {
      const key = l.text.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
      if (!key || seen.has(key)) continue;
      seen.add(key);
      boxes.push({
        title: l.text,
        text: l.text,
        confidence: Math.round(Math.min(0.7, l.conf * 0.7) * 100) / 100, // OCR nunca é tratado como alta confiança
        bbox: [l.x0 / W, l.y0 / H, (l.x1 - l.x0) / W, (l.y1 - l.y0) / H],
        notes: `Texto lido por OCR${l.rot ? ` (girado ${l.rot}°)` : ''}`,
      });
      if (boxes.length >= 15) break;
    }
    return { boxes, raw: { lines: lines.slice(0, 60).map((l) => ({ text: l.text, conf: l.conf, rot: l.rot })) } };
  }
}
