import type { DB } from '../dbtypes';
import type {
  GameSummary, GameDetail, ExpansionStats, GameTag, FieldSource, Loan, RelatedRef, PollRow, Settings,
} from '../../shared/types';
import { DEFAULT_SETTINGS, durationBucket, typicalTime } from '../../shared/domain';
import type { BggThing } from '../bgg/parse';
import { computeBestWith, deriveTags, inferExpansionType, portugueseVersions, relationsOf } from '../bgg/derive';

/** Campos que vêm do BGG e podem ser sobrescritos manualmente (coluna -> chave da API). */
export const BGG_FIELDS: Record<string, string> = {
  name_en: 'nameEn',
  year: 'year',
  description: 'description',
  image_url: 'image',
  thumbnail_url: 'thumb',
  min_players: 'minPlayers',
  max_players: 'maxPlayers',
  playing_time: 'playingTime',
  min_playtime: 'minPlaytime',
  max_playtime: 'maxPlaytime',
  min_age: 'minAge',
  weight: 'weight',
  expansion_type: 'expansionType',
};

/** Campos pessoais: nunca alterados por uma atualização do BGG. */
export const PERSONAL_FIELDS: Record<string, string> = {
  name_pt: 'namePt',
  typical_time_manual: 'typicalTimeManual',
  time_per_player_manual: 'timePerPlayerManual',
  time_base_players_manual: 'timeBasePlayersManual',
  time_note: 'timeNote',
  ownership_status: 'ownershipStatus',
  owner_id: 'ownerId',
  location_type: 'locationType',
  location_person: 'locationPerson',
  location_custom: 'locationCustom',
  loan_date: 'loanDate',
  loan_due_date: 'loanDueDate',
  favorite: 'favorite',
  notes: 'notes',
  acquired_at: 'acquiredAt',
  price_paid: 'pricePaid',
  last_verified_at: 'lastVerifiedAt',
  kind: 'kind',
};

export function getSettings(db: DB): Settings {
  const row = db.prepare(`SELECT value FROM settings WHERE key = 'app'`).get() as { value: string } | undefined;
  try { return { ...DEFAULT_SETTINGS, ...(row ? JSON.parse(row.value) : {}) }; } catch { return DEFAULT_SETTINGS; }
}

function imgUrl(local: string | null, remote: string | null): string | null {
  if (!local) return remote;
  return local.startsWith('data:') ? local : `/images/${encodeURIComponent(local)}`;
}

function parseJson<T>(s: string | null, d: T): T {
  if (!s) return d;
  try { return JSON.parse(s) as T; } catch { return d; }
}

function rowToSummary(r: any): GameSummary {
  return {
    id: r.id,
    bggId: r.bgg_id,
    kind: r.kind,
    standaloneExpansion: !!r.standalone_expansion,
    expansionType: r.expansion_type,
    nameEn: r.name_en,
    namePt: r.name_pt,
    year: r.year,
    thumb: imgUrl(r.thumb_local, r.thumbnail_url) ?? imgUrl(r.image_local, r.image_url),
    minPlayers: r.min_players,
    maxPlayers: r.max_players,
    playingTime: r.playing_time,
    minPlaytime: r.min_playtime,
    maxPlaytime: r.max_playtime,
    typicalTimeManual: r.typical_time_manual,
    weight: r.weight,
    weightVotes: r.weight_votes,
    bestCount1: r.best_count_1,
    bestVotes1: r.best_votes_1,
    bestCount2: r.best_count_2,
    bestVotes2: r.best_votes_2,
    recommendedCounts: parseJson<number[] | null>(r.recommended_counts, null),
    pollTotalVotes: r.poll_total_votes,
    ownershipStatus: r.ownership_status,
    ownerId: r.owner_id,
    locationType: r.location_type,
    locationPerson: r.location_person,
    locationCustom: r.location_custom,
    loanDate: r.loan_date,
    loanDueDate: r.loan_due_date,
    favorite: !!r.favorite,
    dataStatus: r.data_status,
    tags: [],
    mechanics: [],
    categories: [],
    designers: [],
    publishers: [],
    baseIds: [],
    baseNames: [],
    expansionStats: null,
  };
}

const TERM_KEY: Record<string, keyof GameSummary> = {
  mechanic: 'mechanics', category: 'categories', designer: 'designers', publisher: 'publishers',
};

export function listSummaries(db: DB, where = '1=1', params: unknown[] = []): GameSummary[] {
  const rows = db.prepare(`SELECT * FROM games WHERE ${where}`).all(...params) as any[];
  const map = new Map<number, GameSummary>();
  for (const r of rows) map.set(r.id, rowToSummary(r));
  if (!map.size) return [];

  for (const t of db.prepare(`SELECT game_id, tag_id, source FROM game_tags WHERE status = 'active'`).all() as any[]) {
    map.get(t.game_id)?.tags.push({ id: t.tag_id, source: t.source });
  }
  for (const t of db.prepare(`SELECT gt.game_id, t.type, t.name FROM game_bgg_terms gt JOIN bgg_terms t ON t.id = gt.term_id`).all() as any[]) {
    const key = TERM_KEY[t.type];
    const g = map.get(t.game_id);
    if (key && g) (g[key] as string[]).push(t.name);
  }
  const rels = db.prepare(`SELECT r.game_id, r.related_id, COALESCE(b.name_en, r.related_name) name
    FROM game_relations r LEFT JOIN games b ON b.id = r.related_id
    WHERE r.relation = 'expansion_of' AND r.status = 'active'`).all() as any[];
  const me = db.prepare('SELECT id FROM owners WHERE is_me = 1').get() as { id: number } | undefined;
  const expByBase = new Map<number, GameSummary[]>();
  for (const r of rels) {
    const g = map.get(r.game_id);
    if (!g) continue;
    if (r.related_id) g.baseIds.push(r.related_id);
    if (r.name) g.baseNames.push(r.name);
    if (r.related_id) {
      if (!expByBase.has(r.related_id)) expByBase.set(r.related_id, []);
      expByBase.get(r.related_id)!.push(g);
    }
  }
  for (const g of map.values()) {
    if (g.kind !== 'base') continue;
    const exps = expByBase.get(g.id) ?? [];
    if (!exps.length) continue;
    g.expansionStats = expansionStats(g, exps, me?.id ?? null);
  }
  return [...map.values()];
}

export function expansionStats(base: GameSummary, exps: GameSummary[], meId: number | null): ExpansionStats {
  const isCounted = (e: GameSummary) => e.dataStatus !== 'stub' && e.dataStatus !== 'bgg_error'
    && e.expansionType !== 'promo' && e.expansionType !== 'fan' && !e.standaloneExpansion;
  const counted = exps.filter(isCounted);
  const owned = exps.filter((e) => e.ownershipStatus === 'owned');
  const withMe = (e: GameSummary) => e.locationType === 'with_me' || e.locationType === 'borrowed';
  return {
    known: counted.length,
    owned: counted.filter((e) => e.ownershipStatus === 'owned').length,
    wishlist: exps.filter((e) => e.ownershipStatus === 'wishlist').length,
    unverified: exps.filter((e) => e.ownershipStatus === 'unverified' || e.dataStatus === 'stub' || e.dataStatus === 'bgg_error').length,
    promos: exps.filter((e) => e.expansionType === 'promo').length,
    fan: exps.filter((e) => e.expansionType === 'fan').length,
    standalone: exps.filter((e) => e.standaloneExpansion).length,
    withFriends: owned.filter((e) => e.ownerId != null && e.ownerId !== meId).length,
    awayFromHome: owned.filter((e) => !withMe(e)).length,
    ownedWithMeBaseAway: owned.some(withMe) && (base.ownershipStatus !== 'owned' || !withMe(base)),
  };
}

export function getDetail(db: DB, id: number): GameDetail | null {
  const r = db.prepare('SELECT * FROM games WHERE id = ?').get(id) as any;
  if (!r) return null;
  const all = listSummaries(db);
  const summary = all.find((g) => g.id === id)!;
  const tags = db.prepare(`SELECT t.id, t.name, t.grp, gt.source, gt.detail, gt.status FROM game_tags gt JOIN tags t ON t.id = gt.tag_id
    WHERE gt.game_id = ? ORDER BY t.grp, t.sort, t.name`).all(id) as any[];
  const terms = db.prepare(`SELECT t.type, t.name FROM game_bgg_terms gt JOIN bgg_terms t ON t.id = gt.term_id WHERE gt.game_id = ? ORDER BY t.name`).all(id) as any[];
  const termsOf = (type: string) => terms.filter((t) => t.type === type).map((t) => t.name as string);
  const poll = (db.prepare('SELECT num_players, best, recommended, not_recommended FROM player_poll WHERE game_id = ?').all(id) as any[])
    .map((p): PollRow => ({ numPlayers: p.num_players, best: p.best, recommended: p.recommended, notRecommended: p.not_recommended }))
    .sort((a, b) => parseInt(a.numPlayers) - parseInt(b.numPlayers) || a.numPlayers.length - b.numPlayers.length);
  const fieldSources = (db.prepare('SELECT * FROM field_sources WHERE game_id = ? ORDER BY field').all(id) as any[])
    .map((f): FieldSource => ({ field: f.field, source: f.source, status: f.status, note: f.note, updatedAt: f.updated_at }));
  const loans = (db.prepare('SELECT * FROM loans WHERE game_id = ? ORDER BY COALESCE(start_date, created_at) DESC, id DESC').all(id) as any[])
    .map((l): Loan => ({ id: l.id, direction: l.direction, person: l.person, startDate: l.start_date, dueDate: l.due_date, returnedAt: l.returned_at, notes: l.notes }));
  const relRows = db.prepare(`SELECT r.*, g.name_en gname FROM game_relations r LEFT JOIN games g ON g.id = r.related_id
    WHERE r.game_id = ? AND r.status = 'active'`).all(id) as any[];
  const toRef = (x: any): RelatedRef => ({ relationId: x.id, relation: x.relation, source: x.source, gameId: x.related_id, bggId: x.related_bgg_id, name: x.gname ?? x.related_name ?? '?' });
  const expIds = (db.prepare(`SELECT game_id FROM game_relations WHERE related_id = ? AND relation = 'expansion_of' AND status = 'active'`).all(id) as any[]).map((x) => x.game_id);
  const expansions = all.filter((g) => expIds.includes(g.id)).sort((a, b) => (a.year ?? 9999) - (b.year ?? 9999) || a.nameEn.localeCompare(b.nameEn));

  const toTag = (t: any): GameTag => ({ id: t.id, name: t.name, grp: t.grp, source: t.source, detail: t.detail });
  return {
    ...summary,
    bggType: r.bgg_type,
    namePtSource: r.name_pt_source,
    altNames: parseJson(r.alt_names_json, []),
    ptVersions: parseJson(r.pt_versions_json, []),
    description: r.description,
    image: imgUrl(r.image_local, r.image_url) ?? summary.thumb,
    minAge: r.min_age,
    usersRated: r.users_rated,
    avgRating: r.avg_rating,
    bggRank: r.bgg_rank,
    pollBestSummary: r.poll_best_summary,
    pollRecSummary: r.poll_rec_summary,
    poll,
    timePerPlayerManual: r.time_per_player_manual,
    timeBasePlayersManual: r.time_base_players_manual,
    timeNote: r.time_note,
    expansionTypeSource: r.expansion_type_source,
    notes: r.notes,
    acquiredAt: r.acquired_at,
    pricePaid: r.price_paid,
    lastVerifiedAt: r.last_verified_at,
    manualFields: parseJson(r.manual_fields, []),
    bggFetchedAt: r.bgg_fetched_at,
    bggError: r.bgg_error,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
    tags: tags.filter((t) => t.status === 'active').map(toTag),
    rejectedTags: tags.filter((t) => t.status === 'rejected').map(toTag),
    families: termsOf('family'),
    artists: termsOf('artist'),
    subdomains: termsOf('subdomain'),
    fieldSources,
    loans,
    bases: relRows.filter((x) => x.relation === 'expansion_of').map(toRef),
    expansions,
    otherRelations: relRows.filter((x) => x.relation !== 'expansion_of').map(toRef),
  };
}

function setFieldSource(db: DB, gameId: number, field: string, source: FieldSource['source'], status: FieldSource['status'], note: string | null) {
  db.prepare(`INSERT INTO field_sources (game_id, field, source, status, note, updated_at) VALUES (?, ?, ?, ?, ?, datetime('now'))
    ON CONFLICT(game_id, field) DO UPDATE SET source = excluded.source, status = excluded.status, note = excluded.note, updated_at = excluded.updated_at`)
    .run(gameId, field, source, status, note);
}

function termId(db: DB, type: string, name: string, linkId: number | null): number {
  db.prepare('INSERT OR IGNORE INTO bgg_terms (type, name, bgg_link_id) VALUES (?, ?, ?)').run(type, name, linkId);
  return (db.prepare('SELECT id FROM bgg_terms WHERE type = ? AND name = ?').get(type, name) as { id: number }).id;
}

export function tagIdByName(db: DB, name: string, grp = 'custom'): number {
  const row = db.prepare('SELECT id FROM tags WHERE name = ? COLLATE NOCASE').get(name) as { id: number } | undefined;
  if (row) return row.id;
  return Number(db.prepare('INSERT INTO tags (name, grp) VALUES (?, ?)').run(name, grp).lastInsertRowid);
}

const LINK_TERM_TYPES: Record<string, string> = {
  boardgamemechanic: 'mechanic',
  boardgamecategory: 'category',
  boardgamefamily: 'family',
  boardgamedesigner: 'designer',
  boardgamepublisher: 'publisher',
  boardgameartist: 'artist',
};

export interface ApplyOptions {
  /** atualiza esta cópia específica */
  targetId?: number;
  /** cria uma nova cópia mesmo que o jogo já exista (cópia de outro proprietário) */
  createNew?: boolean;
  /** status de propriedade para um registro novo */
  defaults?: Partial<{ ownership_status: string; owner_id: number | null; location_type: string; location_person: string | null; kind: string }>;
}

/**
 * Cria ou atualiza um jogo a partir dos dados do BGG.
 * Campos pessoais e campos marcados como manuais nunca são sobrescritos.
 */
export function applyBggThing(db: DB, t: BggThing, opts: ApplyOptions = {}): number {
  return db.transaction(() => {
    const rows = db.prepare('SELECT * FROM games WHERE bgg_id = ? ORDER BY id').all(t.id) as any[];
    let target = opts.targetId ? rows.find((r) => r.id === opts.targetId) : undefined;
    if (!target && (opts.createNew || !rows.length)) {
      const isExpansion = t.type === 'boardgameexpansion';
      const d = opts.defaults ?? {};
      const info = db.prepare(`INSERT INTO games (bgg_id, name_en, kind, ownership_status, owner_id, location_type, location_person, data_status)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'stub')`).run(
        t.id, t.primaryName, d.kind ?? (isExpansion ? 'expansion' : 'base'),
        d.ownership_status ?? (isExpansion ? 'unverified' : 'owned'),
        d.owner_id ?? null, d.location_type ?? 'with_me', d.location_person ?? null,
      );
      target = db.prepare('SELECT * FROM games WHERE id = ?').get(info.lastInsertRowid);
      rows.push(target);
    }
    target ??= rows[0];
    // os dados oficiais valem para todas as cópias do mesmo jogo (ex.: o seu Dixit e o de um amigo)
    for (const r of rows) applyToRow(db, t, r);
    return target.id as number;
  })();
}

function applyToRow(db: DB, t: BggThing, row: any): number {
  const settings = getSettings(db);
  return db.transaction(() => {
    const isExpansion = t.type === 'boardgameexpansion';
    const id: number = row.id;
    const manual = new Set<string>(parseJson(row.manual_fields, []));
    const weightValid = t.stats?.weight != null && (t.stats.numWeights ?? 0) > 0 && t.stats.weight > 0;
    const best = computeBestWith(t.poll);
    const expType = isExpansion ? inferExpansionType(t) : null;

    const values: Record<string, unknown> = {
      name_en: t.primaryName,
      year: t.year,
      description: t.description,
      image_url: t.image,
      thumbnail_url: t.thumbnail,
      min_players: t.minPlayers,
      max_players: t.maxPlayers,
      playing_time: t.playingTime,
      min_playtime: t.minPlaytime,
      max_playtime: t.maxPlaytime,
      min_age: t.minAge,
      weight: weightValid ? Math.round(t.stats!.weight! * 100) / 100 : null,
    };
    if (isExpansion && row.expansion_type_source !== 'manual') values.expansion_type = expType;

    const sets: string[] = [];
    const params: unknown[] = [];
    for (const [col, v] of Object.entries(values)) {
      if (manual.has(col)) continue;
      sets.push(`${col} = ?`);
      params.push(v);
    }
    const always: Record<string, unknown> = {
      bgg_type: t.type,
      standalone_expansion: relationsOf(t).standaloneExpansion ? 1 : 0,
      alt_names_json: JSON.stringify(t.altNames),
      pt_versions_json: t.versions ? JSON.stringify(portugueseVersions(t)) : row.pt_versions_json,
      weight_votes: t.stats?.numWeights ?? null,
      users_rated: t.stats?.usersRated ?? null,
      avg_rating: t.stats?.average ? Math.round(t.stats.average * 100) / 100 : null,
      bgg_rank: t.stats?.rank ?? null,
      poll_total_votes: t.pollTotalVotes,
      poll_best_summary: t.pollSummaryBest,
      poll_rec_summary: t.pollSummaryRec,
      best_count_1: best.first?.count ?? null,
      best_votes_1: best.first?.votes ?? null,
      best_count_2: best.second?.count ?? null,
      best_votes_2: best.second?.votes ?? null,
      recommended_counts: t.poll.length && (t.pollTotalVotes ?? 0) > 0 ? JSON.stringify(best.recommended) : null,
      data_status: 'bgg_ok',
      bgg_error: null,
      expansion_type_source: isExpansion && row.expansion_type_source !== 'manual' ? (expType ? 'inferred' : null) : row.expansion_type_source,
    };
    for (const [col, v] of Object.entries(always)) { sets.push(`${col} = ?`); params.push(v); }
    if (!manual.has('image_url') && t.image !== row.image_url) sets.push('image_local = NULL');
    if (!manual.has('thumbnail_url') && t.thumbnail !== row.thumbnail_url) sets.push('thumb_local = NULL');
    sets.push(`bgg_fetched_at = datetime('now')`, `updated_at = datetime('now')`);
    db.prepare(`UPDATE games SET ${sets.join(', ')} WHERE id = ?`).run(...params, id);

    // Enquete de jogadores
    db.prepare('DELETE FROM player_poll WHERE game_id = ?').run(id);
    const insPoll = db.prepare('INSERT INTO player_poll (game_id, num_players, best, recommended, not_recommended) VALUES (?, ?, ?, ?, ?)');
    for (const p of t.poll) insPoll.run(id, p.numPlayers, p.best, p.recommended, p.notRecommended);

    // Termos oficiais
    db.prepare('DELETE FROM game_bgg_terms WHERE game_id = ?').run(id);
    const insTerm = db.prepare('INSERT OR IGNORE INTO game_bgg_terms (game_id, term_id) VALUES (?, ?)');
    for (const l of t.links) {
      const type = LINK_TERM_TYPES[l.type];
      if (type) insTerm.run(id, termId(db, type, l.value, l.id));
    }
    for (const r of t.stats?.subdomainRanks ?? []) insTerm.run(id, termId(db, 'subdomain', r.friendlyName.replace(/ Rank$/, ''), null));

    // Etiquetas derivadas (respeita etiquetas manuais e rejeitadas)
    const fresh = db.prepare('SELECT * FROM games WHERE id = ?').get(id) as any;
    const tt = typicalTime({ typicalTimeManual: fresh.typical_time_manual, playingTime: fresh.playing_time, maxPlaytime: fresh.max_playtime, minPlaytime: fresh.min_playtime });
    syncDerivedTags(db, id, deriveTags(t, tt, (m) => durationBucket(m, settings)));

    // Fontes
    const src = (field: string, v: unknown, label: string) => {
      if (manual.has(field)) return;
      setFieldSource(db, id, field, 'bgg', v == null ? 'unavailable' : 'verified', v == null ? `${label}: não informado pelo BGG` : null);
    };
    src('name_en', t.primaryName, 'Nome');
    src('year', t.year, 'Ano');
    src('min_players', t.minPlayers, 'Mínimo de jogadores');
    src('max_players', t.maxPlayers, 'Máximo de jogadores');
    src('playing_time', t.playingTime, 'Tempo de jogo');
    src('min_playtime', t.minPlaytime, 'Tempo mínimo');
    src('max_playtime', t.maxPlaytime, 'Tempo máximo');
    src('image_url', t.image, 'Imagem');
    if (!manual.has('weight')) {
      setFieldSource(db, id, 'weight', 'bgg', weightValid ? 'verified' : 'unavailable',
        weightValid ? `Média de ${t.stats!.numWeights} votos (escala 1–5 do BGG)` : 'Sem votos de peso no BGG');
    }
    const pollVotes = t.pollTotalVotes ?? 0;
    setFieldSource(db, id, 'best_with', 'calculated', pollVotes > 0 && best.first ? 'verified' : 'unverified',
      pollVotes > 0 ? `${best.method} Total de votantes: ${pollVotes}.` : 'Não verificado: a enquete de número de jogadores não tem votos no BGG.');
    setFieldSource(db, id, 'time_per_player', fresh.time_per_player_manual != null ? 'manual' : 'calculated',
      fresh.time_per_player_manual != null ? 'verified' : 'unavailable',
      fresh.time_per_player_manual != null ? 'Estimativa informada por você' : 'Não disponível: o BGG não publica tempo por jogador');
    if (isExpansion && row.expansion_type_source !== 'manual') {
      setFieldSource(db, id, 'expansion_type', 'inferred', expType ? 'unverified' : 'unavailable',
        expType ? 'Inferido pelo nome/categorias do BGG — confira' : 'Tipo não identificável automaticamente');
    }

    // Relações
    const rel = relationsOf(t);
    const upsertRel = { run: (gid: number, bggId: number, _b: number, name: string, relation: string) => upsertRelation(db, gid, bggId, name, relation) };
    if (isExpansion || rel.standaloneExpansion) {
      for (const b of rel.bases) upsertRel.run(id, b.id, b.id, b.value, 'expansion_of');
    }
    for (const l of rel.implementations.filter((x) => x.inbound)) upsertRel.run(id, l.id, l.id, l.value, 'implementation_of');
    for (const l of rel.integrations) upsertRel.run(id, l.id, l.id, l.value, 'integrates_with');
    // Liga relações que apontavam para este jogo só pelo ID do BGG
    resolveRelationsTo(db, id, t.id);
    return id;
  })();
}

export function syncDerivedTags(db: DB, gameId: number, derived: { name: string; source: 'bgg_derived' | 'inferred'; detail: string }[]) {
  const existing = db.prepare('SELECT tag_id, source, status FROM game_tags WHERE game_id = ?').all(gameId) as any[];
  const byTag = new Map(existing.map((e) => [e.tag_id, e]));
  const keep = new Set<number>();
  for (const d of derived) {
    const tid = tagIdByName(db, d.name, 'style');
    keep.add(tid);
    const cur = byTag.get(tid);
    if (!cur) {
      db.prepare('INSERT INTO game_tags (game_id, tag_id, source, detail) VALUES (?, ?, ?, ?)').run(gameId, tid, d.source, d.detail);
    } else if (cur.status === 'active' && cur.source !== 'manual') {
      db.prepare('UPDATE game_tags SET source = ?, detail = ? WHERE game_id = ? AND tag_id = ?').run(d.source, d.detail, gameId, tid);
    }
  }
  // remove derivações que deixaram de valer (nunca as manuais nem as rejeitadas)
  for (const e of existing) {
    if (!keep.has(e.tag_id) && e.source !== 'manual' && e.status === 'active') {
      db.prepare('DELETE FROM game_tags WHERE game_id = ? AND tag_id = ?').run(gameId, e.tag_id);
    }
  }
}

/** Recalcula etiquetas de duração (calculadas) depois de uma edição de tempo. */
export function refreshDurationTag(db: DB, gameId: number) {
  const g = db.prepare('SELECT * FROM games WHERE id = ?').get(gameId) as any;
  if (!g) return;
  const settings = getSettings(db);
  const tt = typicalTime({ typicalTimeManual: g.typical_time_manual, playingTime: g.playing_time, maxPlaytime: g.max_playtime, minPlaytime: g.min_playtime });
  const bucket = durationBucket(tt, settings);
  const durTags = db.prepare(`SELECT gt.tag_id, gt.source, gt.status, t.name FROM game_tags gt JOIN tags t ON t.id = gt.tag_id
    WHERE gt.game_id = ? AND t.grp = 'duration'`).all(gameId) as any[];
  for (const d of durTags) {
    if (d.source === 'inferred' && d.status === 'active' && d.name !== bucket) db.prepare('DELETE FROM game_tags WHERE game_id = ? AND tag_id = ?').run(gameId, d.tag_id);
  }
  if (bucket) {
    const tid = tagIdByName(db, bucket, 'duration');
    const cur = durTags.find((d) => d.tag_id === tid);
    if (!cur) db.prepare(`INSERT INTO game_tags (game_id, tag_id, source, detail) VALUES (?, ?, 'inferred', ?)`).run(gameId, tid, `Calculado a partir do tempo típico (${tt} min)`);
  }
}

export function markBggError(db: DB, gameId: number, message: string) {
  db.prepare(`UPDATE games SET bgg_error = ?, data_status = CASE WHEN data_status = 'stub' THEN 'bgg_error' ELSE data_status END WHERE id = ?`).run(message, gameId);
}

/** Insere/atualiza uma relação vinda do BGG sem duplicar uma relação manual equivalente. */
export function upsertRelation(db: DB, gameId: number, relatedBggId: number, name: string, relation: string) {
  const owner = (db.prepare('SELECT owner_id FROM games WHERE id = ?').get(gameId) as any)?.owner_id ?? null;
  const local = db.prepare(`SELECT id FROM games WHERE bgg_id = ? ORDER BY (owner_id IS ?) DESC, (ownership_status = 'owned') DESC, id LIMIT 1`)
    .get(relatedBggId, owner) as { id: number } | undefined;
  const existing = db.prepare(`SELECT id FROM game_relations WHERE game_id = ? AND relation = ? AND (related_bgg_id = ? OR (related_id IS NOT NULL AND related_id = ?))`)
    .get(gameId, relation, relatedBggId, local?.id ?? -1) as { id: number } | undefined;
  if (existing) {
    db.prepare('UPDATE game_relations SET related_bgg_id = ?, related_name = ?, related_id = COALESCE(related_id, ?) WHERE id = ?').run(relatedBggId, name, local?.id ?? null, existing.id);
  } else {
    db.prepare(`INSERT INTO game_relations (game_id, related_id, related_bgg_id, related_name, relation, source) VALUES (?, ?, ?, ?, ?, 'bgg')`)
      .run(gameId, local?.id ?? null, relatedBggId, name, relation);
  }
}

/** Depois que um jogo ganha ID do BGG, liga a ele as relações pendentes, mesclando duplicatas. */
export function resolveRelationsTo(db: DB, gameId: number, bggId: number) {
  const pending = db.prepare('SELECT * FROM game_relations WHERE related_bgg_id = ? AND related_id IS NULL').all(bggId) as any[];
  for (const r of pending) {
    const dup = db.prepare('SELECT id FROM game_relations WHERE game_id = ? AND relation = ? AND related_id = ? AND id <> ?').get(r.game_id, r.relation, gameId, r.id) as any;
    if (dup) {
      db.prepare('UPDATE game_relations SET related_bgg_id = COALESCE(related_bgg_id, ?) WHERE id = ?').run(bggId, dup.id);
      db.prepare('DELETE FROM game_relations WHERE id = ?').run(r.id);
    } else {
      db.prepare('UPDATE game_relations SET related_id = ? WHERE id = ?').run(gameId, r.id);
    }
  }
}
