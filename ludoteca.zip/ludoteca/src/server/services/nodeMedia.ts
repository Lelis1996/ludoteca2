import fs from 'node:fs';
import path from 'node:path';
import sharp from 'sharp';
import type { MediaStore } from './ports';

/** Fotos da importação guardadas em data/uploads, processadas com sharp. */
export function nodeMediaStore(dir: string): MediaStore {
  fs.mkdirSync(dir, { recursive: true });
  const file = (key: string) => {
    const f = path.resolve(dir, key);
    if (!f.startsWith(path.resolve(dir) + path.sep)) throw new Error('Caminho inválido');
    return f;
  };
  return {
    async normalizePhoto(data) {
      const out = await sharp(data).rotate().resize({ width: 3000, height: 3000, fit: 'inside', withoutEnlargement: true }).jpeg({ quality: 90 }).toBuffer({ resolveWithObject: true });
      return { data: out.data, width: out.info.width, height: out.info.height };
    },
    resize: (data, maxSide, quality = 75) => sharp(data).resize({ width: maxSide, height: maxSide, fit: 'inside', withoutEnlargement: true }).jpeg({ quality }).toBuffer(),
    crop: (data, rect, maxSide) => sharp(data).extract(rect).resize({ width: maxSide, height: maxSide, fit: 'inside' }).jpeg({ quality: 80 }).toBuffer(),
    async save(key, data) {
      const f = file(key);
      fs.mkdirSync(path.dirname(f), { recursive: true });
      fs.writeFileSync(f, data);
    },
    async load(key) { return fs.readFileSync(file(key)); },
    url: (key) => `/uploads/${key}`,
    async removePrefix(prefix) { fs.rmSync(file(prefix.replace(/\/$/, '')), { recursive: true, force: true }); },
  };
}
