import fs from 'node:fs';
import path from 'node:path';
import type { DB } from '../dbtypes';
import type { ImageStore } from './ports';

/**
 * Baixa as imagens das caixas para data/images, para a biblioteca continuar
 * exibindo as capas mesmo quando o BGG estiver fora do ar.
 */
export class ImageCache implements ImageStore {
  private queue: Promise<void> = Promise.resolve();
  constructor(private db: DB, private dir: string, private enabled: boolean, private fetchImpl: typeof fetch = fetch) {
    fs.mkdirSync(dir, { recursive: true });
  }

  schedule(gameId: number) {
    if (!this.enabled) return;
    this.queue = this.queue.then(() => this.download(gameId)).catch(() => undefined);
  }

  /** Aguarda downloads pendentes (usado em testes e no desligamento). */
  idle(): Promise<void> {
    return this.queue;
  }

  private async fetchTo(url: string, file: string): Promise<boolean> {
    try {
      const res = await this.fetchImpl(url, { signal: AbortSignal.timeout(30000) });
      if (!res.ok) return false;
      const buf = Buffer.from(await res.arrayBuffer());
      if (buf.length < 100) return false;
      fs.writeFileSync(file, buf);
      await new Promise((r) => setTimeout(r, 300));
      return true;
    } catch {
      return false;
    }
  }

  private async download(gameId: number) {
    const g = this.db.prepare('SELECT bgg_id, image_url, thumbnail_url, image_local, thumb_local FROM games WHERE id = ?').get(gameId) as any;
    if (!g?.bgg_id) return;
    const ext = (u: string) => (path.extname(new URL(u).pathname).toLowerCase().match(/^\.(jpe?g|png|webp|gif)$/) ? path.extname(new URL(u).pathname).toLowerCase() : '.jpg');
    if (g.thumbnail_url && !g.thumb_local) {
      const name = `${g.bgg_id}-thumb${ext(g.thumbnail_url)}`;
      if (await this.fetchTo(g.thumbnail_url, path.join(this.dir, name))) {
        this.db.prepare('UPDATE games SET thumb_local = ? WHERE id = ?').run(name, gameId);
      }
    }
    if (g.image_url && !g.image_local) {
      const name = `${g.bgg_id}${ext(g.image_url)}`;
      if (await this.fetchTo(g.image_url, path.join(this.dir, name))) {
        this.db.prepare('UPDATE games SET image_local = ? WHERE id = ?').run(name, gameId);
      }
    }
  }
}
