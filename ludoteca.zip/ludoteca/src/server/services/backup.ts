import { z } from 'zod';
import type { DB } from '../dbtypes';
import { HttpError } from './mutations';

export const BACKUP_FORMAT = 'ludoteca-backup';
export const BACKUP_VERSION = 1;

const GAME_COLUMNS = [
  'id', 'bgg_id', 'bgg_type', 'kind', 'standalone_expansion', 'expansion_type', 'expansion_type_source',
  'name_en', 'name_pt', 'name_pt_source', 'alt_names_json', 'pt_versions_json', 'description', 'year',
  'image_url', 'thumbnail_url', 'min_players', 'max_players', 'playing_time', 'min_playtime', 'max_playtime',
  'min_age', 'weight', 'weight_votes', 'users_rated', 'avg_rating', 'bgg_rank', 'poll_total_votes',
  'poll_best_summary', 'poll_rec_summary', 'best_count_1', 'best_votes_1', 'best_count_2', 'best_votes_2',
  'recommended_counts', 'typical_time_manual', 'time_per_player_manual', 'time_base_players_manual', 'time_note',
  'ownership_status', 'owner_id', 'location_type', 'location_person', 'location_custom', 'loan_date',
  'loan_due_date', 'favorite', 'notes', 'acquired_at', 'price_paid', 'last_verified_at', 'manual_fields',
  'data_status', 'bgg_fetched_at', 'bgg_error', 'created_at', 'updated_at',
] as const;

/** Exporta tudo que é necessário para restaurar a coleção sem depender do BGG. */
export function exportJson(db: DB) {
  const all = (sql: string) => db.prepare(sql).all();
  return {
    format: BACKUP_FORMAT,
    version: BACKUP_VERSION,
    exportedAt: new Date().toISOString(),
    owners: all('SELECT id, name, color, is_me FROM owners ORDER BY id'),
    tags: all('SELECT id, name, grp, description, sort FROM tags ORDER BY id'),
    games: all(`SELECT ${GAME_COLUMNS.join(', ')} FROM games ORDER BY id`),
    gameTags: all('SELECT game_id, tag_id, source, detail, status FROM game_tags'),
    bggTerms: all('SELECT id, type, bgg_link_id, name FROM bgg_terms'),
    gameBggTerms: all('SELECT game_id, term_id FROM game_bgg_terms'),
    playerPoll: all('SELECT game_id, num_players, best, recommended, not_recommended FROM player_poll'),
    relations: all('SELECT game_id, related_id, related_bgg_id, related_name, relation, source, status FROM game_relations'),
    loans: all('SELECT game_id, direction, person, start_date, due_date, returned_at, notes, created_at FROM loans'),
    fieldSources: all('SELECT game_id, field, source, status, note, updated_at FROM field_sources'),
    settings: all(`SELECT key, value FROM settings WHERE key = 'app'`),
  };
}

const rowArr = z.array(z.record(z.string(), z.unknown()));
const backupSchema = z.object({
  format: z.literal(BACKUP_FORMAT),
  version: z.number().int().min(1).max(BACKUP_VERSION),
  owners: z.array(z.object({ id: z.number(), name: z.string().min(1), color: z.string(), is_me: z.union([z.number(), z.boolean()]) })),
  tags: z.array(z.object({ id: z.number(), name: z.string().min(1), grp: z.string(), description: z.string().nullable().optional(), sort: z.number().optional() })),
  games: z.array(z.object({ id: z.number(), name_en: z.string().min(1), bgg_id: z.number().nullable().optional() }).passthrough()),
  gameTags: rowArr.default([]),
  bggTerms: rowArr.default([]),
  gameBggTerms: rowArr.default([]),
  playerPoll: rowArr.default([]),
  relations: rowArr.default([]),
  loans: rowArr.default([]),
  fieldSources: rowArr.default([]),
  settings: rowArr.default([]),
});

export interface ImportReport { added: number; skippedDuplicates: number; ownersAdded: number; tagsAdded: number; duplicates: string[] }

/**
 * Importa um backup JSON gerado pela própria aplicação.
 * Mesclagem: jogos já existentes (mesmo ID do BGG, ou mesmo nome + ano sem ID) são ignorados.
 */
export function importJson(db: DB, raw: unknown): ImportReport {
  const parsed = backupSchema.safeParse(raw);
  if (!parsed.success) {
    throw new HttpError(400, 'Arquivo de backup inválido: ' + parsed.error.issues.slice(0, 3).map((i) => `${i.path.join('.')}: ${i.message}`).join('; '));
  }
  const b = parsed.data;
  const report: ImportReport = { added: 0, skippedDuplicates: 0, ownersAdded: 0, tagsAdded: 0, duplicates: [] };
  db.transaction(() => {
    const ownerMap = new Map<number, number>();
    for (const o of b.owners) {
      const isMe = !!o.is_me;
      let row = (isMe ? db.prepare('SELECT id FROM owners WHERE is_me = 1').get() : db.prepare('SELECT id FROM owners WHERE name = ? COLLATE NOCASE').get(o.name)) as any;
      if (!row) {
        row = { id: Number(db.prepare('INSERT INTO owners (name, color, is_me) VALUES (?, ?, 0)').run(o.name, /^#[0-9a-f]{6}$/i.test(o.color) ? o.color : '#9aa0a6').lastInsertRowid) };
        report.ownersAdded++;
      }
      ownerMap.set(o.id, row.id);
    }
    const tagMap = new Map<number, number>();
    for (const t of b.tags) {
      let row = db.prepare('SELECT id FROM tags WHERE name = ? COLLATE NOCASE').get(t.name) as any;
      if (!row) {
        row = { id: Number(db.prepare('INSERT INTO tags (name, grp, description, sort) VALUES (?, ?, ?, ?)').run(t.name, t.grp, t.description ?? null, t.sort ?? 100).lastInsertRowid) };
        report.tagsAdded++;
      }
      tagMap.set(t.id, row.id);
    }
    const termMap = new Map<number, number>();
    for (const t of b.bggTerms as any[]) {
      db.prepare('INSERT OR IGNORE INTO bgg_terms (type, name, bgg_link_id) VALUES (?, ?, ?)').run(t.type, t.name, t.bgg_link_id ?? null);
      termMap.set(t.id, (db.prepare('SELECT id FROM bgg_terms WHERE type = ? AND name = ?').get(t.type, t.name) as any).id);
    }
    const gameMap = new Map<number, number>();
    const newGames = new Set<number>();
    const cols = GAME_COLUMNS.filter((c) => c !== 'id');
    const ins = db.prepare(`INSERT INTO games (${cols.join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`);
    for (const g of b.games as any[]) {
      const owner = g.owner_id == null ? null : ownerMap.get(g.owner_id) ?? null;
      const dup = (g.bgg_id
        ? db.prepare('SELECT id FROM games WHERE bgg_id = ? AND owner_id IS ?').get(g.bgg_id, owner)
        : db.prepare('SELECT id FROM games WHERE bgg_id IS NULL AND lower(name_en) = lower(?) AND year IS ? AND owner_id IS ?').get(g.name_en, g.year ?? null, owner)) as any;
      if (dup) {
        gameMap.set(g.id, dup.id);
        report.skippedDuplicates++;
        report.duplicates.push(g.name_en);
        continue;
      }
      const vals = cols.map((c) => {
        const v = g[c];
        if (c === 'owner_id') return v == null ? null : ownerMap.get(v) ?? null;
        if (typeof v === 'boolean') return v ? 1 : 0;
        if (v !== null && typeof v === 'object') return JSON.stringify(v);
        return v ?? null;
      });
      const fill = (c: string, d: unknown) => { const i = cols.indexOf(c as any); if (vals[i] == null) vals[i] = d; };
      fill('kind', 'base'); fill('ownership_status', 'owned'); fill('location_type', 'with_me');
      fill('favorite', 0); fill('manual_fields', '[]'); fill('data_status', 'manual'); fill('standalone_expansion', 0);
      fill('created_at', new Date().toISOString().replace('T', ' ').slice(0, 19));
      fill('updated_at', new Date().toISOString().replace('T', ' ').slice(0, 19));
      const id = Number(ins.run(...vals).lastInsertRowid);
      gameMap.set(g.id, id);
      newGames.add(id);
      report.added++;
    }
    const gid = (old: unknown) => gameMap.get(Number(old));
    for (const r of b.gameTags as any[]) {
      const g = gid(r.game_id), t = tagMap.get(Number(r.tag_id));
      if (g && t && newGames.has(g)) db.prepare('INSERT OR IGNORE INTO game_tags (game_id, tag_id, source, detail, status) VALUES (?, ?, ?, ?, ?)').run(g, t, r.source ?? 'manual', r.detail ?? null, r.status ?? 'active');
    }
    for (const r of b.gameBggTerms as any[]) {
      const g = gid(r.game_id), t = termMap.get(Number(r.term_id));
      if (g && t && newGames.has(g)) db.prepare('INSERT OR IGNORE INTO game_bgg_terms (game_id, term_id) VALUES (?, ?)').run(g, t);
    }
    for (const r of b.playerPoll as any[]) {
      const g = gid(r.game_id);
      if (g && newGames.has(g)) db.prepare('INSERT OR IGNORE INTO player_poll (game_id, num_players, best, recommended, not_recommended) VALUES (?, ?, ?, ?, ?)').run(g, String(r.num_players), r.best ?? 0, r.recommended ?? 0, r.not_recommended ?? 0);
    }
    for (const r of b.relations as any[]) {
      const g = gid(r.game_id);
      if (!g || !newGames.has(g)) continue;
      const rel = r.related_id != null ? gid(r.related_id) ?? null : null;
      const relLocal = rel ?? (r.related_bgg_id ? (db.prepare('SELECT id FROM games WHERE bgg_id = ?').get(r.related_bgg_id) as any)?.id ?? null : null);
      db.prepare('INSERT OR IGNORE INTO game_relations (game_id, related_id, related_bgg_id, related_name, relation, source, status) VALUES (?, ?, ?, ?, ?, ?, ?)')
        .run(g, relLocal, r.related_bgg_id ?? null, r.related_name ?? null, r.relation, r.source ?? 'manual', r.status ?? 'active');
    }
    for (const r of b.loans as any[]) {
      const g = gid(r.game_id);
      if (g && newGames.has(g)) db.prepare('INSERT INTO loans (game_id, direction, person, start_date, due_date, returned_at, notes) VALUES (?, ?, ?, ?, ?, ?, ?)').run(g, r.direction, r.person ?? null, r.start_date ?? null, r.due_date ?? null, r.returned_at ?? null, r.notes ?? null);
    }
    for (const r of b.fieldSources as any[]) {
      const g = gid(r.game_id);
      if (g && newGames.has(g)) db.prepare('INSERT OR IGNORE INTO field_sources (game_id, field, source, status, note, updated_at) VALUES (?, ?, ?, ?, ?, ?)').run(g, r.field, r.source, r.status, r.note ?? null, r.updated_at ?? new Date().toISOString());
    }
  })();
  return report;
}

function csvCell(v: unknown): string {
  if (v == null) return '';
  const s = String(v);
  return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export function exportCsv(db: DB): string {
  const rows = db.prepare(`SELECT g.*, o.name owner_name,
      (SELECT group_concat(t.name, '; ') FROM game_tags gt JOIN tags t ON t.id = gt.tag_id WHERE gt.game_id = g.id AND gt.status = 'active') tags,
      (SELECT group_concat(t.name, '; ') FROM game_bgg_terms x JOIN bgg_terms t ON t.id = x.term_id WHERE x.game_id = g.id AND t.type = 'mechanic') mechanics,
      (SELECT group_concat(t.name, '; ') FROM game_bgg_terms x JOIN bgg_terms t ON t.id = x.term_id WHERE x.game_id = g.id AND t.type = 'category') categories,
      (SELECT group_concat(t.name, '; ') FROM game_bgg_terms x JOIN bgg_terms t ON t.id = x.term_id WHERE x.game_id = g.id AND t.type = 'designer') designers,
      (SELECT group_concat(t.name, '; ') FROM game_bgg_terms x JOIN bgg_terms t ON t.id = x.term_id WHERE x.game_id = g.id AND t.type = 'publisher') publishers,
      (SELECT group_concat(COALESCE(b.name_en, r.related_name), '; ') FROM game_relations r LEFT JOIN games b ON b.id = r.related_id WHERE r.game_id = g.id AND r.relation = 'expansion_of' AND r.status = 'active') base_games
    FROM games g LEFT JOIN owners o ON o.id = g.owner_id ORDER BY g.kind, g.name_en`).all() as any[];
  const cols: [string, (r: any) => unknown][] = [
    ['id', (r) => r.id], ['bgg_id', (r) => r.bgg_id], ['bgg_url', (r) => r.bgg_id ? `https://boardgamegeek.com/boardgame/${r.bgg_id}` : ''],
    ['tipo', (r) => r.kind === 'expansion' ? 'expansão' : 'jogo-base'], ['jogo_base', (r) => r.base_games],
    ['nome_en', (r) => r.name_en], ['nome_pt', (r) => r.name_pt], ['ano', (r) => r.year],
    ['jogadores_min', (r) => r.min_players], ['jogadores_max', (r) => r.max_players],
    ['melhor_com_1', (r) => r.best_count_1], ['votos_1', (r) => r.best_votes_1],
    ['melhor_com_2', (r) => r.best_count_2], ['votos_2', (r) => r.best_votes_2],
    ['recomendado_com', (r) => (r.recommended_counts ? JSON.parse(r.recommended_counts).join(' ') : '')],
    ['tempo_min', (r) => r.min_playtime], ['tempo_max', (r) => r.max_playtime], ['tempo_tipico_bgg', (r) => r.playing_time],
    ['tempo_tipico_manual', (r) => r.typical_time_manual], ['min_por_jogador_manual', (r) => r.time_per_player_manual],
    ['peso', (r) => r.weight], ['votos_peso', (r) => r.weight_votes],
    ['status', (r) => r.ownership_status], ['proprietario', (r) => r.owner_name], ['localizacao', (r) => r.location_type],
    ['com_quem', (r) => r.location_person], ['local_personalizado', (r) => r.location_custom],
    ['data_emprestimo', (r) => r.loan_date], ['devolucao_prevista', (r) => r.loan_due_date],
    ['favorito', (r) => (r.favorite ? 'sim' : '')], ['etiquetas', (r) => r.tags], ['mecanicas_bgg', (r) => r.mechanics],
    ['categorias_bgg', (r) => r.categories], ['designers', (r) => r.designers], ['editoras', (r) => r.publishers],
    ['data_aquisicao', (r) => r.acquired_at], ['preco_pago', (r) => r.price_paid], ['observacoes', (r) => r.notes],
    ['dados_bgg_em', (r) => r.bgg_fetched_at],
  ];
  const lines = [cols.map(([h]) => h).join(',')];
  for (const r of rows) lines.push(cols.map(([, f]) => csvCell(f(r))).join(','));
  return '﻿' + lines.join('\n') + '\n';
}
