/**
 * Coleção inicial, identificada a partir das fotos enviadas em 22/10/2026.
 * Entra como cadastro manual (sem dados do BGG); depois, "Vincular ao BGG"
 * busca cada jogo no BGG e mostra uma revisão antes de vincular.
 */
import type { DB } from '../dbtypes';
import { getSetting, setSetting } from '../core';
import { addRelation, createManualGame } from './mutations';

export const SEED_COLLECTION_VERSION = 1;

type SeedGame = string | { name: string; namePt?: string; expansions?: (string | { name: string; namePt?: string })[] };

interface SeedOwner {
  owner: string;
  color: string;
  isMe?: boolean;
  location: 'with_me' | 'with_friend';
  games: SeedGame[];
}

export const SEED_COLLECTION: SeedOwner[] = [
  {
    owner: 'Meus jogos', color: '#f5f1e8', isMe: true, location: 'with_me',
    games: [
      'El Grande',
      { name: 'Everdell', expansions: ['Everdell: Spirecrest'] },
      'The Castles of Burgundy',
      'Bärenpark',
      'The King Is Dead',
      'Clans of Caledonia',
      { name: 'The Isle of Cats', expansions: ['The Isle of Cats: Late Arrivals', 'The Isle of Cats: Kittens + Beasts'] },
      "Darwin's Journey",
      { name: 'Wingspan', expansions: ['Wingspan: Oceania Expansion', 'Wingspan: European Expansion'] },
      'Sintonia',
      'Cascadia',
      'Trekking Through History',
      { name: 'The Taverns of Tiefenthal', expansions: ['The Taverns of Tiefenthal: Open Doors!'] },
      'Ticket to Ride: Europe',
      { name: 'Paladins of the West Kingdom', namePt: 'Paladinos do Reino Ocidental', expansions: [{ name: 'Paladins of the West Kingdom: City of Crowns', namePt: 'Cidade das Coroas' }] },
      { name: 'Architects of the West Kingdom', namePt: 'Arquitetos do Reino Ocidental', expansions: [{ name: 'Architects of the West Kingdom: Age of Artisans', namePt: 'Era dos Artesãos' }] },
      'Ra',
      { name: 'Terraforming Mars', expansions: ['Terraforming Mars: Turmoil'] },
      'Dixit',
      'Puerto Rico',
      'Sugar Gliders',
      'Parks',
      'The Quest for El Dorado',
      'Keyflower',
      { name: 'Five Tribes', namePt: 'Five Tribes: Os Djinns de Naqala' },
      'Splendor Pokémon',
      'Samurai',
      'UNO',
      'Jaipur',
      'The Crew: Mission Deep Sea',
      'The Fox in the Forest Duet',
      'Agent Avenue',
      'The Mind',
      'Dobble',
      'Azul Mini',
    ],
  },
  {
    owner: 'Arthur Bunte', color: '#1b2a6b', location: 'with_friend',
    games: [
      'Splendor Pokémon', 'Spirit Island', 'Carcassonne Plus', 'Great Western Trail', 'Harmonies', 'The Resistance',
      'A Frota Perdida', 'Brass: Birmingham', 'Robinson Crusoe: Adventures on the Cursed Island', 'Evolution: Climate',
      'Entre Linhas', 'Gaia Project', 'Yokai', 'Scythe', 'Zombicide: Black Plague', 'Azul', 'Top!',
    ],
  },
  {
    owner: 'André Salim', color: '#22c55e', location: 'with_friend',
    games: [
      'Catan', '7 Wonders', '7 Wonders Duel',
      { name: 'Heat: Pedal to the Metal', expansions: ['Heat: Heavy Rain'] },
      'Finspan', 'Verdant', 'Splendor', 'Pandemic', 'Dobble', 'Black Stories', 'The Mind', 'Dixit',
      { name: 'Telestrations: After Dark', namePt: 'Telestrations Na Madruga' },
      'Race for the Galaxy', 'Stone Age', 'Power Grid', 'Concordia Venus',
    ],
  },
];

export function seedGameCount(): number {
  return SEED_COLLECTION.reduce((n, o) => n + o.games.reduce((m, g) => m + 1 + (typeof g === 'string' ? 0 : g.expansions?.length ?? 0), 0), 0);
}

/**
 * Cadastra a coleção inicial. Idempotente: só roda uma vez por banco
 * (a não ser que `force` seja usado, e mesmo assim não duplica jogos do mesmo proprietário).
 */
export function applySeedCollection(db: DB, force = false): { added: number; skipped: number } {
  if (!force && getSetting(db, 'seed_collection', null)) return { added: 0, skipped: 0 };
  let added = 0, skipped = 0;
  db.transaction(() => {
    for (const o of SEED_COLLECTION) {
      let owner = (o.isMe
        ? db.prepare('SELECT id FROM owners WHERE is_me = 1').get()
        : db.prepare('SELECT id FROM owners WHERE name = ? COLLATE NOCASE').get(o.owner)) as { id: number } | undefined;
      if (!owner) owner = { id: Number(db.prepare('INSERT INTO owners (name, color) VALUES (?, ?)').run(o.owner, o.color).lastInsertRowid) };
      const person = o.location === 'with_friend' ? o.owner : null;
      const exists = (name: string) => db.prepare('SELECT id FROM games WHERE lower(name_en) = lower(?) AND owner_id = ?').get(name, owner!.id) as { id: number } | undefined;
      const create = (name: string, namePt: string | undefined, kind: 'base' | 'expansion', baseGameId?: number) => {
        const found = exists(name);
        if (found) { skipped++; return found.id; }
        added++;
        return createManualGame(db, {
          nameEn: name, namePt: namePt ?? null, kind, baseGameId: baseGameId ?? null, ownershipStatus: 'owned', ownerId: owner!.id,
          locationType: o.location, locationPerson: person, allowDuplicate: true,
        });
      };
      for (const g of o.games) {
        const spec = typeof g === 'string' ? { name: g } : g;
        const baseId = create(spec.name, spec.namePt, 'base');
        for (const e of spec.expansions ?? []) {
          const es = typeof e === 'string' ? { name: e } : e;
          const eid = create(es.name, es.namePt, 'expansion', baseId);
          addRelation(db, eid, baseId);
        }
      }
    }
    setSetting(db, 'seed_collection', { version: SEED_COLLECTION_VERSION, appliedAt: new Date().toISOString() });
  })();
  return { added, skipped };
}
