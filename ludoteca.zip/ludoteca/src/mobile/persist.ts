import { Capacitor } from '@capacitor/core';
import { Directory, Filesystem } from '@capacitor/filesystem';
import { fromBase64, toBase64 } from './bytes';

/**
 * Guarda o arquivo do banco no aparelho:
 * - no app Android: pasta privada do app (Directory.Data);
 * - no navegador (testes/PWA): IndexedDB.
 */
const FILE = 'ludoteca.db';
const native = () => Capacitor.isNativePlatform();

function idb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open('ludoteca', 1);
    req.onupgradeneeded = () => req.result.createObjectStore('files');
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function loadDbBytes(): Promise<Uint8Array | null> {
  if (native()) {
    try {
      const r = await Filesystem.readFile({ path: FILE, directory: Directory.Data });
      return fromBase64(typeof r.data === 'string' ? r.data : toBase64(new Uint8Array(await (r.data as Blob).arrayBuffer())));
    } catch {
      return null;
    }
  }
  const d = await idb();
  return new Promise((resolve) => {
    const req = d.transaction('files').objectStore('files').get(FILE);
    req.onsuccess = () => resolve(req.result ? new Uint8Array(req.result) : null);
    req.onerror = () => resolve(null);
  });
}

export async function saveDbBytes(bytes: Uint8Array): Promise<void> {
  if (native()) {
    // grava em arquivo temporário e renomeia: um corte de energia não corrompe o banco
    await Filesystem.writeFile({ path: `${FILE}.tmp`, data: toBase64(bytes), directory: Directory.Data });
    await Filesystem.rename({ from: `${FILE}.tmp`, to: FILE, directory: Directory.Data, toDirectory: Directory.Data });
    return;
  }
  const d = await idb();
  await new Promise<void>((resolve, reject) => {
    const tx = d.transaction('files', 'readwrite');
    tx.objectStore('files').put(bytes, FILE);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}
