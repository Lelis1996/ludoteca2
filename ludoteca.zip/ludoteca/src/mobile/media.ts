import type { DB } from '../server/dbtypes';
import type { ImageStore, MediaStore } from '../server/services/ports';
import type { VisionImageOps } from '../server/vision/core';
import { toBase64 } from './bytes';
import { httpGetBytes } from './http';

async function decode(data: Uint8Array): Promise<ImageBitmap> {
  // respeita a orientação EXIF das fotos do celular
  return createImageBitmap(new Blob([data as BlobPart]), { imageOrientation: 'from-image' });
}

function canvas(w: number, h: number): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return c;
}

async function toJpeg(c: HTMLCanvasElement, quality = 0.85): Promise<Uint8Array> {
  const blob = await new Promise<Blob | null>((r) => c.toBlob(r, 'image/jpeg', quality));
  if (!blob) throw new Error('Falha ao gerar imagem');
  return new Uint8Array(await blob.arrayBuffer());
}

function fit(w: number, h: number, max: number) {
  const s = Math.min(1, max / Math.max(w, h));
  return { w: Math.max(1, Math.round(w * s)), h: Math.max(1, Math.round(h * s)) };
}

async function resizeTo(data: Uint8Array, max: number, quality = 0.85) {
  const bmp = await decode(data);
  const { w, h } = fit(bmp.width, bmp.height, max);
  const c = canvas(w, h);
  c.getContext('2d')!.drawImage(bmp, 0, 0, w, h);
  bmp.close();
  return { data: await toJpeg(c, quality), width: w, height: h, canvas: c };
}

/** Fotos da importação guardadas dentro do próprio banco (tabela blobs). */
export function browserMediaStore(db: DB): MediaStore {
  const urls = new Map<string, string>();
  return {
    async normalizePhoto(data) {
      const r = await resizeTo(data, 2400, 0.9);
      return { data: r.data, width: r.width, height: r.height };
    },
    async resize(data, maxSide, quality = 75) { return (await resizeTo(data, maxSide, quality / 100)).data; },
    async crop(data, rect, maxSide) {
      const bmp = await decode(data);
      const { w, h } = fit(rect.width, rect.height, maxSide);
      const c = canvas(w, h);
      c.getContext('2d')!.drawImage(bmp, rect.left, rect.top, rect.width, rect.height, 0, 0, w, h);
      bmp.close();
      return toJpeg(c, 0.8);
    },
    async save(key, data) {
      db.prepare(`INSERT INTO blobs (key, mime, data) VALUES (?, 'image/jpeg', ?) ON CONFLICT(key) DO UPDATE SET data = excluded.data`).run(key, data);
      urls.delete(key);
    },
    async load(key) {
      const r = db.prepare('SELECT data FROM blobs WHERE key = ?').get(key) as { data: Uint8Array } | undefined;
      if (!r) throw new Error('Arquivo não encontrado');
      return r.data;
    },
    url(key) {
      let u = urls.get(key);
      if (!u) {
        const r = db.prepare('SELECT mime, data FROM blobs WHERE key = ?').get(key) as { mime: string; data: Uint8Array } | undefined;
        if (!r) return '';
        u = URL.createObjectURL(new Blob([r.data as BlobPart], { type: r.mime }));
        urls.set(key, u);
      }
      return u;
    },
    async removePrefix(prefix) {
      db.prepare('DELETE FROM blobs WHERE key LIKE ?').run(`${prefix}%`);
      for (const k of [...urls.keys()]) if (k.startsWith(prefix)) { URL.revokeObjectURL(urls.get(k)!); urls.delete(k); }
    },
  };
}

/** Miniaturas das capas salvas no banco (data URL) para aparecerem sem internet. */
export function browserImageStore(db: DB): ImageStore {
  let queue: Promise<void> = Promise.resolve();
  const run = async (gameId: number) => {
    const g = db.prepare('SELECT thumbnail_url, thumb_local FROM games WHERE id = ?').get(gameId) as any;
    if (!g?.thumbnail_url || g.thumb_local) return;
    try {
      const bytes = await httpGetBytes(g.thumbnail_url);
      if (bytes.length < 100 || bytes.length > 400_000) return;
      const mime = g.thumbnail_url.toLowerCase().endsWith('.png') ? 'image/png' : 'image/jpeg';
      db.prepare('UPDATE games SET thumb_local = ? WHERE thumbnail_url = ? AND thumb_local IS NULL').run(`data:${mime};base64,${toBase64(bytes)}`, g.thumbnail_url);
    } catch { /* sem internet: tenta na próxima atualização */ }
  };
  return {
    schedule(gameId) { queue = queue.then(() => run(gameId)).catch(() => undefined); },
    idle: () => queue,
  };
}

/** Operações de imagem para o reconhecimento (canvas). */
export const browserVisionOps: VisionImageOps = {
  async jpegBase64(image, maxSide) { return toBase64((await resizeTo(image, maxSide, 0.85)).data); },
  async forOcr(image, maxSide) {
    const base = await resizeTo(image, maxSide, 0.92);
    const src = base.canvas;
    return {
      width: base.width,
      height: base.height,
      async rotated(deg) {
        const swap = deg === 90 || deg === 270;
        const c = canvas(swap ? src.height : src.width, swap ? src.width : src.height);
        const ctx = c.getContext('2d')!;
        ctx.filter = 'grayscale(1)';
        ctx.translate(c.width / 2, c.height / 2);
        ctx.rotate((deg * Math.PI) / 180);
        ctx.drawImage(src, -src.width / 2, -src.height / 2);
        return new Promise<Blob>((r) => c.toBlob((b) => r(b!), 'image/png'));
      },
    };
  },
};
