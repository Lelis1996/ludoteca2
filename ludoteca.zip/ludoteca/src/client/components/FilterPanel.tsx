import { useMemo, useState } from 'react';
import { useStore } from '../lib/store';
import { DEFAULT_FILTERS, type Filters, type CollectionScope, type ExpansionFilter } from '../../shared/filter';
import { weightBandRange } from '../../shared/domain';
import { Icon } from './Icon';

const COLLECTION: [CollectionScope, string][] = [
  ['physical', 'Coleção física (meus + amigos)'],
  ['mine', 'Só meus jogos'],
  ['friends', 'Jogos de amigos'],
  ['wishlist', 'Quero comprar'],
  ['want_to_try', 'Quero experimentar'],
  ['reference', 'Só consulta / não possuo'],
  ['all', 'Todos os registros'],
];
const TIME_QUICK: [string, number | null, number | null][] = [
  ['até 30', null, 30], ['30–60', 30, 60], ['60–90', 60, 90], ['90–120', 90, 120], ['120+', 120, null],
];
const EXP_FILTERS: [ExpansionFilter, string][] = [
  ['any', 'Sem filtro de expansões'],
  ['missing', 'Possuo o jogo e faltam expansões'],
  ['complete', 'Tenho todas as expansões conhecidas'],
  ['wishlist', 'Com expansões que quero comprar'],
  ['exp_with_friends', 'Expansões que estão com amigos'],
  ['pending', 'Expansões pendentes de verificação'],
];
const TAG_GROUPS: [string, string][] = [
  ['style', 'Estilo e experiência'],
  ['mechanic', 'Mecânicas'],
  ['interaction', 'Interação'],
  ['luck', 'Sorte'],
  ['duration', 'Duração'],
  ['custom', 'Minhas etiquetas'],
];

export function FilterPanel({ filters, setFilters, open, onClose }: {
  filters: Filters; setFilters: (f: Filters | ((p: Filters) => Filters)) => void; open: boolean; onClose: () => void;
}) {
  const { owners, tags, settings, games } = useStore();
  const [showAllTags, setShowAllTags] = useState(false);
  const set = <K extends keyof Filters>(k: K, v: Filters[K]) => setFilters((f) => ({ ...f, [k]: v }));

  const usedTagIds = useMemo(() => {
    const s = new Set<number>();
    for (const g of games) for (const t of g.tags) s.add(t.id);
    return s;
  }, [games]);

  const cycleTag = (id: number) => setFilters((f) => {
    if (f.tagInclude.includes(id)) return { ...f, tagInclude: f.tagInclude.filter((x) => x !== id), tagExclude: [...f.tagExclude, id] };
    if (f.tagExclude.includes(id)) return { ...f, tagExclude: f.tagExclude.filter((x) => x !== id) };
    return { ...f, tagInclude: [...f.tagInclude, id] };
  });

  const bands = [...settings.weightBands].sort((a, b) => a.min - b.min);
  const timeQuickOn = (min: number | null, max: number | null) => filters.timeMin === min && filters.timeMax === max;

  return (
    <aside className={`sidebar${open ? ' open' : ''}`} aria-label="Filtros">
      <div className="btn-row mobile-only" style={{ justifyContent: 'space-between', marginBottom: 10 }}>
        <strong>Filtros</strong>
        <button className="btn ghost icon" onClick={onClose} aria-label="Fechar filtros"><Icon name="x" /></button>
      </div>

      <div className="fgroup">
        <h4>Quantos vão jogar?</h4>
        <div className="num-row" role="group" aria-label="Número de jogadores">
          {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
            <button key={n} className={filters.players === n ? 'on' : ''} aria-pressed={filters.players === n}
              onClick={() => set('players', filters.players === n ? null : n)}>{n}</button>
          ))}
        </div>
        <div className="seg full" style={{ marginTop: 8 }} role="group" aria-label="Critério de jogadores">
          <button className={filters.playersMode === 'supports' ? 'on' : ''} onClick={() => set('playersMode', 'supports')} title="Faixa oficial de jogadores do jogo">Suporta</button>
          <button className={filters.playersMode === 'recommended' ? 'on' : ''} onClick={() => set('playersMode', 'recommended')} title="A comunidade do BGG recomenda (Best + Recommended > Not Recommended)">Recomendado</button>
          <button className={filters.playersMode === 'best' ? 'on' : ''} onClick={() => set('playersMode', 'best')} title="Entre as duas quantidades mais votadas como 'Best' no BGG">Melhor com</button>
        </div>
        <div className="hint" style={{ marginTop: 6 }}>
          {filters.playersMode === 'supports' ? 'Faixa oficial (caixa/BGG).' : filters.playersMode === 'recommended' ? 'Recomendado pela comunidade do BGG.' : 'Entre as 2 mais votadas como “Best” no BGG.'}
        </div>
      </div>

      <div className="fgroup">
        <h4>Duração (min) {(filters.timeMin != null || filters.timeMax != null) && <button className="btn ghost small" onClick={() => setFilters((f) => ({ ...f, timeMin: null, timeMax: null }))}>limpar</button>}</h4>
        <div className="chips" style={{ marginBottom: 8 }}>
          {TIME_QUICK.map(([label, min, max]) => (
            <button key={label} className={`chip${timeQuickOn(min, max) ? ' include' : ''}`} onClick={() => setFilters((f) => timeQuickOn(min, max) ? { ...f, timeMin: null, timeMax: null } : { ...f, timeMin: min, timeMax: max })}>{label}</button>
          ))}
        </div>
        <div className="range">
          <input className="input" type="number" min={0} placeholder="mín." aria-label="Duração mínima" value={filters.timeMin ?? ''} onChange={(e) => set('timeMin', e.target.value === '' ? null : Number(e.target.value))} />
          <span className="muted">a</span>
          <input className="input" type="number" min={0} placeholder="máx." aria-label="Duração máxima" value={filters.timeMax ?? ''} onChange={(e) => set('timeMax', e.target.value === '' ? null : Number(e.target.value))} />
        </div>
      </div>

      <div className="fgroup">
        <h4>Complexidade (peso BGG) {(filters.weightMin > 1 || filters.weightMax < 5) && <button className="btn ghost small" onClick={() => setFilters((f) => ({ ...f, weightMin: 1, weightMax: 5 }))}>limpar</button>}</h4>
        <div className="chips" style={{ marginBottom: 10 }}>
          {bands.map((b) => {
            const r = weightBandRange(b.label, bands)!;
            const on = filters.weightMin === r[0] && Math.abs(filters.weightMax - Math.min(5, r[1] - 0.01)) < 0.001;
            return <button key={b.label} className={`chip${on ? ' include' : ''}`} onClick={() => setFilters((f) => on ? { ...f, weightMin: 1, weightMax: 5 } : { ...f, weightMin: r[0], weightMax: Math.min(5, r[1] - 0.01) })}>{b.label}</button>;
          })}
        </div>
        <div className="dual-range">
          <div className="track" />
          <div className="fill" style={{ left: `${((filters.weightMin - 1) / 4) * 100}%`, right: `${100 - ((filters.weightMax - 1) / 4) * 100}%` }} />
          <input type="range" min={1} max={5} step={0.05} value={filters.weightMin} aria-label="Peso mínimo"
            onChange={(e) => set('weightMin', Math.min(Number(e.target.value), filters.weightMax))} />
          <input type="range" min={1} max={5} step={0.05} value={filters.weightMax} aria-label="Peso máximo"
            onChange={(e) => set('weightMax', Math.max(Number(e.target.value), filters.weightMin))} />
        </div>
        <div className="hint" style={{ display: 'flex', justifyContent: 'space-between' }}><span>{filters.weightMin.toFixed(2)}</span><span>{filters.weightMax.toFixed(2)}</span></div>
      </div>

      <div className="fgroup">
        <h4>Coleção</h4>
        <div className="radio-list">
          {COLLECTION.map(([v, label]) => <button key={v} className={filters.collection === v ? 'on' : ''} onClick={() => set('collection', v)}>{label}</button>)}
        </div>
      </div>

      <div className="fgroup">
        <h4>Proprietário {filters.ownerIds.length > 0 && <button className="btn ghost small" onClick={() => set('ownerIds', [])}>todos</button>}</h4>
        <div className="chips">
          {owners.map((o) => {
            const on = filters.ownerIds.includes(o.id);
            return (
              <button key={o.id} className={`chip${on ? ' include' : ''}`} aria-pressed={on}
                onClick={() => set('ownerIds', on ? filters.ownerIds.filter((x) => x !== o.id) : [...filters.ownerIds, o.id])}>
                <span className="owner-dot" style={{ background: o.color }} />{o.name}
              </button>
            );
          })}
        </div>
      </div>

      <div className="fgroup">
        <h4>Etiquetas <span className="hint" style={{ textTransform: 'none', letterSpacing: 0 }}>clique: incluir · 2×: excluir</span></h4>
        {TAG_GROUPS.map(([grp, label]) => {
          const list = tags.filter((t) => t.grp === grp && (showAllTags || usedTagIds.has(t.id) || filters.tagInclude.includes(t.id) || filters.tagExclude.includes(t.id)));
          if (!list.length) return null;
          return (
            <div key={grp} style={{ marginBottom: 10 }}>
              <div className="hint" style={{ marginBottom: 5 }}>{label}</div>
              <div className="chips">
                {list.map((t) => {
                  const st = filters.tagInclude.includes(t.id) ? 'include' : filters.tagExclude.includes(t.id) ? 'exclude' : '';
                  return <button key={t.id} className={`chip ${st}`} onClick={() => cycleTag(t.id)} aria-label={`${t.name}${st === 'include' ? ' (incluída)' : st === 'exclude' ? ' (excluída)' : ''}`}>{st === 'include' && '✓ '}{t.name}</button>;
                })}
              </div>
            </div>
          );
        })}
        <button className="btn ghost small" onClick={() => setShowAllTags(!showAllTags)}>{showAllTags ? 'Mostrar só etiquetas em uso' : 'Mostrar todas as etiquetas'}</button>
      </div>

      <div className="fgroup">
        <h4>Expansões</h4>
        <div className="seg full" role="group" aria-label="Exibição de expansões">
          <button className={filters.expansions === 'hide' ? 'on' : ''} onClick={() => set('expansions', 'hide')}>Ocultar</button>
          <button className={filters.expansions === 'include' ? 'on' : ''} onClick={() => set('expansions', 'include')}>Incluir</button>
          <button className={filters.expansions === 'only' ? 'on' : ''} onClick={() => set('expansions', 'only')}>Só expansões</button>
        </div>
        <select className="input" style={{ marginTop: 8 }} value={filters.expansionFilter} aria-label="Filtro de expansões"
          onChange={(e) => set('expansionFilter', e.target.value as ExpansionFilter)}>
          {EXP_FILTERS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </select>
      </div>

      <div className="fgroup">
        <label className="check"><input type="checkbox" checked={filters.favoritesOnly} onChange={(e) => set('favoritesOnly', e.target.checked)} />Só favoritos</label>
      </div>

      <div style={{ paddingTop: 14 }}>
        <button className="btn" style={{ width: '100%', justifyContent: 'center' }} onClick={() => setFilters({ ...DEFAULT_FILTERS, sort: filters.sort, sortDir: filters.sortDir })}>
          <Icon name="x" size={14} />Limpar todos os filtros
        </button>
      </div>
    </aside>
  );
}
