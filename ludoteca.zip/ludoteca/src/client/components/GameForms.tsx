import { useState } from 'react';
import { api } from '../lib/api';
import { useStore } from '../lib/store';
import type { GameDetail, LocationType, OwnershipStatus, ExpansionType } from '../../shared/types';
import { EXPANSION_TYPE_LABELS, LOCATION_LABELS, OWNERSHIP_LABELS } from '../../shared/domain';
import { Modal } from './ui';
import { Icon } from './Icon';

type Update = (fn: () => Promise<GameDetail>, msg?: string) => Promise<boolean>;

export function OwnershipForm({ g, update }: { g: GameDetail; update: Update }) {
  const { owners } = useStore();
  const [f, setF] = useState({
    ownershipStatus: g.ownershipStatus, ownerId: g.ownerId, locationType: g.locationType, locationPerson: g.locationPerson ?? '',
    locationCustom: g.locationCustom ?? '', loanDate: g.loanDate ?? '', loanDueDate: g.loanDueDate ?? '', notes: g.notes ?? '',
    acquiredAt: g.acquiredAt ?? '', pricePaid: g.pricePaid?.toString() ?? '', lastVerifiedAt: g.lastVerifiedAt ?? '',
  });
  const set = (k: keyof typeof f, v: unknown) => setF((p) => ({ ...p, [k]: v }));
  const needsPerson = f.locationType === 'with_friend' || f.locationType === 'lent_out' || f.locationType === 'borrowed';
  const isLoan = f.locationType === 'lent_out' || f.locationType === 'borrowed';
  const ownerIsMe = owners.find((o) => o.id === Number(f.ownerId))?.isMe;

  const save = () => update(() => api.patchGame(g.id, {
    ownershipStatus: f.ownershipStatus,
    ownerId: f.ownerId == null || (f.ownerId as unknown) === '' ? null : Number(f.ownerId),
    locationType: f.locationType,
    locationPerson: needsPerson ? f.locationPerson || null : null,
    locationCustom: f.locationType === 'other' ? f.locationCustom || null : null,
    loanDate: isLoan ? f.loanDate || null : null,
    loanDueDate: isLoan ? f.loanDueDate || null : null,
    notes: f.notes || null,
    acquiredAt: f.acquiredAt || null,
    pricePaid: f.pricePaid === '' ? null : Number(f.pricePaid.replace(',', '.')),
    lastVerifiedAt: f.lastVerifiedAt || null,
  }), 'Propriedade e localização salvas.');

  return (
    <>
      <div className="grid-2">
        <label className="field"><span>Status</span>
          <select className="input" value={f.ownershipStatus} onChange={(e) => set('ownershipStatus', e.target.value as OwnershipStatus)}>
            {(Object.keys(OWNERSHIP_LABELS) as OwnershipStatus[]).map((k) => <option key={k} value={k}>{OWNERSHIP_LABELS[k]}</option>)}
          </select>
        </label>
        <label className="field"><span>Proprietário</span>
          <select className="input" value={f.ownerId ?? ''} onChange={(e) => set('ownerId', e.target.value === '' ? null : Number(e.target.value))}>
            <option value="">— sem proprietário —</option>
            {owners.map((o) => <option key={o.id} value={o.id}>{o.name}</option>)}
          </select>
        </label>
      </div>
      <div className="hint">
        “Possuo” = faz parte da coleção física (sua ou de um amigo, conforme o proprietário). Os demais status ficam só para consulta ou planejamento.
      </div>
      <div className="grid-2">
        <label className="field"><span>Onde está agora</span>
          <select className="input" value={f.locationType} onChange={(e) => set('locationType', e.target.value as LocationType)}>
            {(Object.keys(LOCATION_LABELS) as LocationType[]).map((k) => <option key={k} value={k}>{LOCATION_LABELS[k]}</option>)}
          </select>
        </label>
        {needsPerson && (
          <label className="field"><span>{f.locationType === 'borrowed' ? 'Quem emprestou' : 'Com quem está'}</span>
            <input className="input" value={f.locationPerson} onChange={(e) => set('locationPerson', e.target.value)} list="people" placeholder="Nome" />
            <datalist id="people">{owners.filter((o) => !o.isMe).map((o) => <option key={o.id} value={o.name} />)}</datalist>
          </label>
        )}
        {f.locationType === 'other' && (
          <label className="field"><span>Local</span><input className="input" value={f.locationCustom} onChange={(e) => set('locationCustom', e.target.value)} placeholder="ex.: casa da praia, clube" /></label>
        )}
      </div>
      {f.locationType === 'with_me' && f.ownerId != null && !ownerIsMe && (
        <div className="hint">Jogo de outra pessoa guardado com você. Se foi emprestado, prefira “Emprestado por alguém” para registrar a data.</div>
      )}
      {isLoan && (
        <div className="grid-2">
          <label className="field"><span>Data do empréstimo</span><input className="input" type="date" value={f.loanDate} onChange={(e) => set('loanDate', e.target.value)} /></label>
          <label className="field"><span>Devolução prevista (opcional)</span><input className="input" type="date" value={f.loanDueDate} onChange={(e) => set('loanDueDate', e.target.value)} /></label>
        </div>
      )}
      <div className="grid-3">
        <label className="field"><span>Data de aquisição</span><input className="input" type="date" value={f.acquiredAt} onChange={(e) => set('acquiredAt', e.target.value)} /></label>
        <label className="field"><span>Preço pago (R$)</span><input className="input" inputMode="decimal" value={f.pricePaid} onChange={(e) => set('pricePaid', e.target.value)} /></label>
        <label className="field"><span>Última verificação</span><input className="input" type="date" value={f.lastVerifiedAt} onChange={(e) => set('lastVerifiedAt', e.target.value)} /></label>
      </div>
      <label className="field"><span>Observações</span><textarea className="input" value={f.notes} onChange={(e) => set('notes', e.target.value)} placeholder="Estado da caixa, sleeves, componentes faltando..." /></label>
      <div className="btn-row">
        <button className="btn primary" onClick={save}><Icon name="check" />Salvar</button>
        {(g.locationType === 'lent_out' || g.locationType === 'borrowed') && (
          <button className="btn" onClick={() => update(() => api.returnGame(g.id), 'Devolução registrada.')}>Registrar devolução</button>
        )}
      </div>
      {g.loans.length > 0 && (
        <div>
          <div className="label" style={{ margin: '10px 0 6px' }}>Histórico de empréstimos</div>
          <table className="poll">
            <thead><tr><th>Tipo</th><th style={{ textAlign: 'left' }}>Pessoa</th><th>Início</th><th>Previsto</th><th>Devolvido</th></tr></thead>
            <tbody>{g.loans.map((l) => (
              <tr key={l.id}>
                <td>{l.direction === 'lent_out' ? 'Emprestei' : 'Peguei emprestado'}</td>
                <td style={{ textAlign: 'left' }}>{l.person ?? '—'}</td>
                <td>{fmt(l.startDate)}</td><td>{fmt(l.dueDate)}</td>
                <td>{l.returnedAt ? fmt(l.returnedAt) : <span className="badge warn">em aberto</span>}</td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      )}
    </>
  );
}

function fmt(d: string | null) {
  if (!d) return '—';
  const x = new Date(d.length === 10 ? d + 'T12:00' : d.replace(' ', 'T'));
  return Number.isNaN(x.getTime()) ? d : x.toLocaleDateString('pt-BR');
}

/** Edição de qualquer campo do jogo. Campos vindos do BGG editados aqui ficam protegidos contra atualizações. */
export function DataEditForm({ g, onClose, update }: { g: GameDetail; onClose: () => void; update: Update }) {
  const [f, setF] = useState({
    nameEn: g.nameEn, namePt: g.namePt ?? '', year: g.year?.toString() ?? '', minPlayers: g.minPlayers?.toString() ?? '',
    maxPlayers: g.maxPlayers?.toString() ?? '', playingTime: g.playingTime?.toString() ?? '', minPlaytime: g.minPlaytime?.toString() ?? '',
    maxPlaytime: g.maxPlaytime?.toString() ?? '', minAge: g.minAge?.toString() ?? '', weight: g.weight?.toString() ?? '',
    image: g.image && !g.image.startsWith('/images/') ? g.image : '', description: g.description ?? '', kind: g.kind,
    expansionType: g.expansionType ?? '',
  });
  const [err, setErr] = useState<string | null>(null);
  const set = (k: keyof typeof f, v: string) => setF((p) => ({ ...p, [k]: v }));
  const n = (s: string) => (s.trim() === '' ? null : Number(s.replace(',', '.')));
  const orig: Record<string, unknown> = {
    nameEn: g.nameEn, namePt: g.namePt, year: g.year, minPlayers: g.minPlayers, maxPlayers: g.maxPlayers, playingTime: g.playingTime,
    minPlaytime: g.minPlaytime, maxPlaytime: g.maxPlaytime, minAge: g.minAge, weight: g.weight, description: g.description, kind: g.kind,
    expansionType: g.expansionType, image: g.image && !g.image.startsWith('/images/') ? g.image : null,
  };

  const submit = async () => {
    const next: Record<string, unknown> = {
      nameEn: f.nameEn.trim(), namePt: f.namePt.trim() || null, year: n(f.year), minPlayers: n(f.minPlayers), maxPlayers: n(f.maxPlayers),
      playingTime: n(f.playingTime), minPlaytime: n(f.minPlaytime), maxPlaytime: n(f.maxPlaytime), minAge: n(f.minAge), weight: n(f.weight),
      description: f.description.trim() || null, kind: f.kind, expansionType: f.expansionType || null, image: f.image.trim() || null,
    };
    if (!next.nameEn) return setErr('Informe o nome.');
    if (next.weight != null && ((next.weight as number) < 1 || (next.weight as number) > 5)) return setErr('O peso deve estar entre 1 e 5.');
    // envia só o que mudou, para não marcar como manual o que não foi tocado
    const patch = Object.fromEntries(Object.entries(next).filter(([k, v]) => v !== (orig[k] ?? null)));
    if (!Object.keys(patch).length) return onClose();
    if ('image' in patch) patch.thumb = patch.image;
    const ok = await update(() => api.patchGame(g.id, patch), 'Dados salvos.');
    if (ok) onClose();
  };

  return (
    <Modal title="Editar dados do jogo" onClose={onClose} wide footer={<>
      <button className="btn ghost" onClick={onClose}>Cancelar</button>
      <button className="btn primary" onClick={submit}>Salvar</button>
    </>}>
      {g.bggId && <div className="notice info"><Icon name="info" />Campos do BGG que você alterar aqui passam a ser “manuais” e não serão sobrescritos nas próximas atualizações (dá para desfazer em “Fontes dos dados”).</div>}
      {err && <div className="error-text">{err}</div>}
      <div className="grid-2">
        <label className="field"><span>Nome oficial (inglês)</span><input className="input" value={f.nameEn} onChange={(e) => set('nameEn', e.target.value)} /></label>
        <label className="field"><span>Nome em português</span><input className="input" value={f.namePt} onChange={(e) => set('namePt', e.target.value)} list="altnames" placeholder="Somente se confirmado" />
          <datalist id="altnames">{g.altNames.map((a) => <option key={a} value={a} />)}</datalist>
        </label>
      </div>
      {g.altNames.length > 0 && <div className="hint">Nomes alternativos no BGG (idioma não informado): {g.altNames.slice(0, 12).join(' · ')}</div>}
      <div className="grid-4">
        <label className="field"><span>Ano</span><input className="input" type="number" value={f.year} onChange={(e) => set('year', e.target.value)} /></label>
        <label className="field"><span>Mín. jogadores</span><input className="input" type="number" min={1} value={f.minPlayers} onChange={(e) => set('minPlayers', e.target.value)} /></label>
        <label className="field"><span>Máx. jogadores</span><input className="input" type="number" min={1} value={f.maxPlayers} onChange={(e) => set('maxPlayers', e.target.value)} /></label>
        <label className="field"><span>Idade mínima</span><input className="input" type="number" min={0} value={f.minAge} onChange={(e) => set('minAge', e.target.value)} /></label>
        <label className="field"><span>Tempo mín. (min)</span><input className="input" type="number" min={1} value={f.minPlaytime} onChange={(e) => set('minPlaytime', e.target.value)} /></label>
        <label className="field"><span>Tempo máx. (min)</span><input className="input" type="number" min={1} value={f.maxPlaytime} onChange={(e) => set('maxPlaytime', e.target.value)} /></label>
        <label className="field"><span>Tempo típico (min)</span><input className="input" type="number" min={1} value={f.playingTime} onChange={(e) => set('playingTime', e.target.value)} /></label>
        <label className="field"><span>Peso (1–5)</span><input className="input" inputMode="decimal" value={f.weight} onChange={(e) => set('weight', e.target.value)} /></label>
      </div>
      <div className="grid-2">
        <label className="field"><span>Tipo de item</span>
          <select className="input" value={f.kind} onChange={(e) => set('kind', e.target.value)}>
            <option value="base">Jogo-base / independente</option><option value="expansion">Expansão</option>
          </select>
        </label>
        {f.kind === 'expansion' && (
          <label className="field"><span>Tipo de expansão</span>
            <select className="input" value={f.expansionType} onChange={(e) => set('expansionType', e.target.value)}>
              <option value="">Não identificado</option>
              {(Object.keys(EXPANSION_TYPE_LABELS) as ExpansionType[]).map((k) => <option key={k} value={k}>{EXPANSION_TYPE_LABELS[k]}</option>)}
            </select>
          </label>
        )}
      </div>
      <label className="field"><span>URL da imagem da caixa</span><input className="input" value={f.image} onChange={(e) => set('image', e.target.value)} placeholder="https://..." /></label>
      <label className="field"><span>Descrição</span><textarea className="input" rows={5} value={f.description} onChange={(e) => set('description', e.target.value)} /></label>
    </Modal>
  );
}
