import { useMemo, useState } from 'react';
import { useStore } from '../lib/store';
import { api } from '../lib/api';
import { applyFilters, activeFilterCount, DEFAULT_FILTERS, type Filters, type SortKey } from '../../shared/filter';
import { formatPlayers, typicalTime, weightLabel, OWNERSHIP_LABELS } from '../../shared/domain';
import type { GameSummary } from '../../shared/types';
import { FilterPanel } from '../components/FilterPanel';
import { Icon } from '../components/Icon';
import { BestWith, Cover, GameName, GameStats, OwnerTag, WeightPill, ownerColor } from '../components/ui';

const SORTS: [SortKey, string][] = [
  ['name', 'Nome'], ['added', 'Adicionados recentemente'], ['weight', 'Peso'], ['time', 'Duração'],
  ['players', 'Máx. de jogadores'], ['year', 'Ano'], ['best', 'Votos "Best"'],
];

export function Library({ filters, setFilters, view, setView, openGame, onAdd }: {
  filters: Filters; setFilters: (f: Filters | ((p: Filters) => Filters)) => void;
  view: 'grid' | 'list'; setView: (v: 'grid' | 'list') => void; openGame: (id: number) => void; onAdd: () => void;
}) {
  const { games, owners, tags, status, loaded, loadError, settings } = useStore();
  const [panelOpen, setPanelOpen] = useState(false);
  const [linking, setLinking] = useState(false);
  const { toast } = useStore();
  const startLink = async () => {
    setLinking(true);
    try { const b = await api.linkBggBatch(); window.location.hash = `/importar/${b.id}`; }
    catch (e) { toast((e as Error).message, 'error'); } finally { setLinking(false); }
  };
  const { items, matchedViaExpansion } = useMemo(() => applyFilters(games, filters, { owners, tags }), [games, filters, owners, tags]);
  const nActive = activeFilterCount(filters);
  const tagName = useMemo(() => new Map(tags.map((t) => [t.id, t.name])), [tags]);
  const me = owners.find((o) => o.isMe);

  const presets: { label: string; apply: Partial<Filters> }[] = [
    { label: 'Leves para ensinar', apply: { weightMin: 1, weightMax: 1.99 } },
    { label: 'Pesados e estratégicos', apply: { weightMin: 3, weightMax: 5, tagInclude: tags.filter((t) => t.name === 'Estratégico').map((t) => t.id) } },
    { label: 'Menos de 1 hora', apply: { timeMin: null, timeMax: 60 } },
    { label: 'Cooperativos', apply: { tagInclude: tags.filter((t) => t.name === 'Cooperativo').map((t) => t.id) } },
  ];

  const sortBy = (k: SortKey) => setFilters((f) => ({ ...f, sort: k, sortDir: f.sort === k && f.sortDir === 'asc' ? 'desc' : 'asc' }));

  return (
    <div className="layout">
      <FilterPanel filters={filters} setFilters={setFilters} open={panelOpen} onClose={() => setPanelOpen(false)} />
      <main className="main">
        {loadError && <div className="notice danger"><Icon name="alert" />Não foi possível carregar a coleção: {loadError}</div>}
        {status && !status.bggConfigured && (
          <div className="notice warn"><Icon name="info" />
            <div>BGG não configurado: {status.unlinkedCount ? `${status.unlinkedCount} jogos estão só com o nome, sem dados do BGG. ` : 'busca e atualização de dados estão desligadas. '}Coloque seu token em <a href="#/configuracoes">Configurações</a> para buscar jogadores, tempo, peso e capas.</div>
          </div>
        )}
        {status?.bggConfigured && !!status.unlinkedCount && (
          <div className="notice info" style={{ alignItems: 'center' }}><Icon name="info" />
            <div style={{ flex: 1 }}>{status.unlinkedCount} jogo(s) ainda sem dados do BGG. O app procura cada um no BGG e mostra uma revisão antes de vincular.</div>
            <button className="btn primary small" disabled={linking} onClick={startLink}>{linking ? 'Preparando…' : 'Vincular ao BGG'}</button>
          </div>
        )}
        <div className="toolbar">
          <button className="btn mobile-only" onClick={() => setPanelOpen(true)}><Icon name="filter" />Filtros{nActive ? ` (${nActive})` : ''}</button>
          <div className="count"><b>{items.length}</b> {items.length === 1 ? 'resultado' : 'resultados'}</div>
          {nActive > 0 && <button className="btn ghost small" onClick={() => setFilters({ ...DEFAULT_FILTERS, sort: filters.sort, sortDir: filters.sortDir })}>Limpar filtros ({nActive})</button>}
          <div className="spacer" />
          <select className="input" style={{ width: 'auto' }} value={filters.sort} aria-label="Ordenar por" onChange={(e) => setFilters((f) => ({ ...f, sort: e.target.value as SortKey }))}>
            {SORTS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
          </select>
          <button className="btn icon" title={filters.sortDir === 'asc' ? 'Crescente' : 'Decrescente'} aria-label="Inverter ordem"
            onClick={() => setFilters((f) => ({ ...f, sortDir: f.sortDir === 'asc' ? 'desc' : 'asc' }))}>{filters.sortDir === 'asc' ? '↑' : '↓'}</button>
          <div className="seg" role="group" aria-label="Visualização">
            <button className={view === 'grid' ? 'on' : ''} onClick={() => setView('grid')} aria-label="Grade"><Icon name="grid" size={15} /></button>
            <button className={view === 'list' ? 'on' : ''} onClick={() => setView('list')} aria-label="Lista"><Icon name="list" size={15} /></button>
          </div>
        </div>

        <div className="active-filters">
          {presets.map((p) => (
            <button key={p.label} className="chip" onClick={() => setFilters((f) => ({ ...f, ...p.apply }))}>{p.label}</button>
          ))}
        </div>

        {loaded && games.length === 0 ? (
          <div className="empty">
            <h3>Sua ludoteca está vazia</h3>
            <p>Adicione jogos buscando no BoardGameGeek, cadastrando manualmente ou enviando fotos da estante.</p>
            <div className="btn-row" style={{ justifyContent: 'center' }}>
              <button className="btn primary" onClick={onAdd}><Icon name="plus" />Adicionar jogo</button>
              <a className="btn" href="#/importar"><Icon name="camera" />Importar por fotos</a>
            </div>
          </div>
        ) : items.length === 0 ? (
          <div className="empty"><h3>Nenhum jogo com esses filtros</h3><p>Tente remover algum filtro.</p></div>
        ) : view === 'grid' ? (
          <div className="grid">
            {items.map((g) => (
              <button key={g.id} className="card" onClick={() => openGame(g.id)} aria-label={`Abrir ${g.nameEn}`}>
                <div className="cover">
                  <Cover src={g.thumb} name={g.nameEn} />
                  <div className="corner">
                    {g.kind === 'expansion' && <span className="badge accent">Expansão</span>}
                    {g.ownershipStatus !== 'owned' && <span className="badge">{OWNERSHIP_LABELS[g.ownershipStatus]}</span>}
                  </div>
                  {g.favorite && <span className="fav" aria-label="Favorito">★</span>}
                </div>
                <div className="card-body">
                  <div>
                    <GameName game={g} />
                    {(g.namePt || g.year || g.baseNames.length > 0) && (
                      <div className="game-sub">{[g.namePt, g.kind === 'expansion' && g.baseNames.length ? `de ${g.baseNames[0]}` : null, g.year].filter(Boolean).join(' · ')}</div>
                    )}
                  </div>
                  <OwnerTag game={g} />
                  <GameStats game={g} />
                  {matchedViaExpansion.has(g.id) && <div className="hint">Expansão encontrada: {matchedViaExpansion.get(g.id)!.slice(0, 2).join(', ')}</div>}
                  {g.expansionStats && g.expansionStats.known > 0 && (
                    <div className="hint">Expansões: {g.expansionStats.owned} de {g.expansionStats.known}</div>
                  )}
                  <div className="chips">
                    {g.tags.filter((t) => !['Duração curta', 'Duração média', 'Duração longa'].includes(tagName.get(t.id) ?? '')).slice(0, 3).map((t) => (
                      <span key={t.id} className={`chip src-${t.source}`}>{tagName.get(t.id)}</span>
                    ))}
                  </div>
                </div>
              </button>
            ))}
          </div>
        ) : (
          <div className="table-wrap">
            <table className="games">
              <thead>
                <tr>
                  <th />
                  <th><button className={filters.sort === 'name' ? 'sorted' : ''} onClick={() => sortBy('name')}>Nome</button></th>
                  <th>Proprietário / local</th>
                  <th><button className={filters.sort === 'players' ? 'sorted' : ''} onClick={() => sortBy('players')}>Jogadores</button></th>
                  <th><button className={filters.sort === 'best' ? 'sorted' : ''} onClick={() => sortBy('best')}>Melhor com</button></th>
                  <th><button className={filters.sort === 'time' ? 'sorted' : ''} onClick={() => sortBy('time')}>Tempo</button></th>
                  <th><button className={filters.sort === 'weight' ? 'sorted' : ''} onClick={() => sortBy('weight')}>Peso</button></th>
                  <th><button className={filters.sort === 'year' ? 'sorted' : ''} onClick={() => sortBy('year')}>Ano</button></th>
                  <th>Etiquetas</th>
                </tr>
              </thead>
              <tbody>
                {items.map((g) => <Row key={g.id} g={g} open={() => openGame(g.id)} tagName={tagName} />)}
              </tbody>
            </table>
          </div>
        )}
        <div className="hint" style={{ marginTop: 16 }}>
          Cor do nome = proprietário{me ? ` (${me.name} em ${me.color})` : ''}. Peso: média de votos do BGG (1–5); rótulos como “{weightLabel(2.5, settings.weightBands)}” são da aplicação.
        </div>
      </main>
    </div>
  );
}

function Row({ g, open, tagName }: { g: GameSummary; open: () => void; tagName: Map<number, string> }) {
  const { ownerById } = useStore();
  const owner = ownerById(g.ownerId);
  const t = typicalTime(g);
  return (
    <tr onClick={open} tabIndex={0} onKeyDown={(e) => { if (e.key === 'Enter') open(); }}>
      <td>{g.thumb ? <img className="thumb" src={g.thumb} alt="" loading="lazy" /> : <div className="thumb" />}</td>
      <td>
        <span className="game-name" style={{ fontSize: 15, color: g.ownershipStatus === 'owned' && owner ? ownerColor(owner) : 'var(--text-2)' }}>{g.nameEn}</span>
        {g.favorite && <span style={{ color: 'var(--accent)' }}> ★</span>}
        {g.kind === 'expansion' && <span className="badge accent" style={{ marginLeft: 6 }}>Expansão</span>}
        {g.namePt && <div className="game-sub">{g.namePt}</div>}
      </td>
      <td>
        <div className="owner-line"><span className="owner-dot" style={{ background: g.ownershipStatus === 'owned' ? owner?.color : 'transparent', border: g.ownershipStatus === 'owned' ? undefined : '1px dashed var(--muted)' }} />
          {g.ownershipStatus === 'owned' ? owner?.name ?? '—' : OWNERSHIP_LABELS[g.ownershipStatus]}</div>
      </td>
      <td>{formatPlayers(g.minPlayers, g.maxPlayers)}</td>
      <td><BestWith game={g} compact /></td>
      <td>{t ? `${t} min` : <span className="unverified">n/d</span>}</td>
      <td><WeightPill weight={g.weight} /></td>
      <td>{g.year ?? '—'}</td>
      <td><div className="chips">{g.tags.slice(0, 3).map((x) => <span key={x.id} className={`chip src-${x.source}`}>{tagName.get(x.id)}</span>)}</div></td>
    </tr>
  );
}
