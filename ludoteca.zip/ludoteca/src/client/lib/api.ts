import type { AppStatus, BggSearchResult, GameDetail, GameSummary, Owner, Settings, Tag } from '../../shared/types';

export class ApiError extends Error {
  constructor(message: string, public status: number, public body: any) { super(message); }
}

/** App de celular: as chamadas vão para o "servidor" embutido, sem rede. */
export const EMBEDDED = import.meta.env.VITE_EMBEDDED === '1';
let backend: Promise<import('../../mobile/backend').LocalBackend> | null = null;
export function localBackend() {
  backend ??= import('../../mobile/backend').then((m) => m.startBackend());
  return backend;
}

async function req<T>(method: string, url: string, body?: unknown, isForm = false): Promise<T> {
  if (EMBEDDED) {
    const r = await (await localBackend()).dispatch(method, url, body);
    if (r.status >= 400) throw new ApiError(r.data?.error ?? `Erro ${r.status}`, r.status, r.data);
    return r.data as T;
  }
  const res = await fetch(url, {
    method,
    headers: body && !isForm ? { 'Content-Type': 'application/json' } : undefined,
    body: body === undefined ? undefined : isForm ? (body as FormData) : JSON.stringify(body),
  });
  const text = await res.text();
  let data: any = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!res.ok) throw new ApiError(data?.error ?? `Erro ${res.status}`, res.status, data);
  return data as T;
}

export const api = {
  status: () => req<AppStatus & { bestWithMethod: string }>('GET', '/api/status'),
  settings: () => req<Settings>('GET', '/api/settings'),
  saveSettings: (s: Settings) => req<Settings>('PUT', '/api/settings', s),

  owners: () => req<Owner[]>('GET', '/api/owners'),
  createOwner: (o: { name: string; color: string }) => req<Owner>('POST', '/api/owners', o),
  updateOwner: (id: number, o: { name: string; color: string }) => req<Owner>('PUT', `/api/owners/${id}`, o),
  deleteOwner: (id: number, reassignTo?: number) => req('DELETE', `/api/owners/${id}${reassignTo ? `?reassignTo=${reassignTo}` : ''}`),

  tags: () => req<Tag[]>('GET', '/api/tags'),
  createTag: (t: { name: string; grp: string; description?: string | null }) => req<Tag>('POST', '/api/tags', t),
  updateTag: (id: number, t: { name: string; grp: string; description?: string | null }) => req<Tag>('PUT', `/api/tags/${id}`, t),
  deleteTag: (id: number) => req('DELETE', `/api/tags/${id}`),

  games: () => req<GameSummary[]>('GET', '/api/games'),
  game: (id: number) => req<GameDetail>('GET', `/api/games/${id}`),
  createGame: (g: Record<string, unknown>) => req<GameDetail>('POST', '/api/games', g),
  addFromBgg: (b: Record<string, unknown>) => req<GameDetail>('POST', '/api/games/from-bgg', b),
  patchGame: (id: number, p: Record<string, unknown>) => req<GameDetail>('PATCH', `/api/games/${id}`, p),
  deleteGame: (id: number) => req<{ deletedExpansionStubs: number }>('DELETE', `/api/games/${id}`),
  refreshGame: (id: number) => req<GameDetail>('POST', `/api/games/${id}/refresh`),
  refreshExpansions: (id: number, onlyMissing = false) =>
    req<{ updated: number; notExpansion: number; errors: string[]; game: GameDetail }>('POST', `/api/games/${id}/expansions/refresh`, { onlyMissing }),
  linkBgg: (id: number, bggId: number) => req<GameDetail>('POST', `/api/games/${id}/link-bgg`, { bggId }),
  restoreField: (id: number, field: string) => req<GameDetail>('POST', `/api/games/${id}/restore-field`, { field }),
  addTag: (id: number, t: { tagId?: number; name?: string }) => req<GameDetail>('POST', `/api/games/${id}/tags`, t),
  removeTag: (id: number, tagId: number) => req<GameDetail>('DELETE', `/api/games/${id}/tags/${tagId}`),
  restoreTag: (id: number, tagId: number) => req<GameDetail>('POST', `/api/games/${id}/tags/${tagId}/restore`),
  addRelation: (id: number, baseGameId: number) => req<GameDetail>('POST', `/api/games/${id}/relations`, { baseGameId }),
  removeRelation: (relId: number) => req<GameDetail>('DELETE', `/api/relations/${relId}`),
  returnGame: (id: number) => req<GameDetail>('POST', `/api/games/${id}/return`),

  bggSearch: (q: string) => req<BggSearchResult[]>('GET', `/api/bgg/search?q=${encodeURIComponent(q)}`),

  secrets: () => req<{ bggToken: string | null; anthropicKey: string | null; visionModel: string }>('GET', '/api/secrets'),
  saveSecrets: (s: Record<string, string | null>) => req('PUT', '/api/secrets', s),
  linkBggBatch: (gameIds?: number[]) => req<any>('POST', '/api/imports/link-bgg', { gameIds }),
  exportData: (kind: 'json' | 'csv') => req<any>('GET', `/api/export.${kind}`),
  importBackup: (data: unknown) => req<{ added: number; skippedDuplicates: number; ownersAdded: number; tagsAdded: number; duplicates: string[] }>('POST', '/api/import-backup', data),

  imports: () => req<any[]>('GET', '/api/imports'),
  importBatch: (id: number) => req<any>('GET', `/api/imports/${id}`),
  createImport: (form: FormData) => req<any>('POST', '/api/imports', form, true),
  deleteImport: (id: number) => req('DELETE', `/api/imports/${id}`),
  updateCandidate: (id: number, p: Record<string, unknown>) => req('PATCH', `/api/import-candidates/${id}`, p),
  searchCandidate: (id: number, query: string) => req('POST', `/api/import-candidates/${id}/search`, { query }),
  addCandidate: (photoId: number, title: string) => req('POST', `/api/import-photos/${photoId}/candidates`, { title }),
  commitImport: (id: number, p: Record<string, unknown>) => req<{ added: number; updated: number; duplicates: number; errors: string[] }>('POST', `/api/imports/${id}/commit`, p),
};
