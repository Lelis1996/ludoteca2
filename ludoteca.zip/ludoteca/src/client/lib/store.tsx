import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { AppStatus, GameSummary, Owner, Settings, Tag } from '../../shared/types';
import { DEFAULT_SETTINGS } from '../../shared/domain';
import { api } from './api';

type Toast = { id: number; text: string; kind: 'ok' | 'error' | 'info' };

interface Store {
  loaded: boolean;
  loadError: string | null;
  games: GameSummary[];
  owners: Owner[];
  tags: Tag[];
  settings: Settings;
  status: (AppStatus & { bestWithMethod: string }) | null;
  reload: () => Promise<void>;
  reloadGames: () => Promise<void>;
  reloadOwners: () => Promise<void>;
  reloadTags: () => Promise<void>;
  setSettings: (s: Settings) => void;
  toast: (text: string, kind?: Toast['kind']) => void;
  toasts: Toast[];
  ownerById: (id: number | null) => Owner | undefined;
}

const Ctx = createContext<Store | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [games, setGames] = useState<GameSummary[]>([]);
  const [owners, setOwners] = useState<Owner[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [status, setStatus] = useState<Store['status']>(null);
  const [loaded, setLoaded] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);

  const toast = useCallback((text: string, kind: Toast['kind'] = 'ok') => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, text, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), kind === 'error' ? 7000 : 3500);
  }, []);

  const reloadGames = useCallback(async () => { setGames(await api.games()); }, []);
  const reloadOwners = useCallback(async () => { setOwners(await api.owners()); }, []);
  const reloadTags = useCallback(async () => { setTags(await api.tags()); }, []);
  const reload = useCallback(async () => {
    try {
      const [g, o, t, s, st] = await Promise.all([api.games(), api.owners(), api.tags(), api.settings(), api.status()]);
      setGames(g); setOwners(o); setTags(t); setSettings(s); setStatus(st);
      setLoadError(null);
    } catch (e) {
      setLoadError((e as Error).message);
    } finally {
      setLoaded(true);
    }
  }, []);

  useEffect(() => { void reload(); }, [reload]);

  const ownerMap = useMemo(() => new Map(owners.map((o) => [o.id, o])), [owners]);
  const value: Store = {
    loaded, loadError, games, owners, tags, settings, status, reload, reloadGames, reloadOwners, reloadTags,
    setSettings, toast, toasts, ownerById: (id) => (id == null ? undefined : ownerMap.get(id)),
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore(): Store {
  const s = useContext(Ctx);
  if (!s) throw new Error('StoreProvider ausente');
  return s;
}

/** Roteamento simples por hash: #/, #/jogo/12, #/importar, #/importar/3, #/proprietarios, #/etiquetas, #/configuracoes */
export function useRoute(): { path: string[]; go: (to: string) => void } {
  const parse = () => window.location.hash.replace(/^#\/?/, '').split('?')[0].split('/').filter(Boolean);
  const [path, setPath] = useState<string[]>(parse);
  useEffect(() => {
    const on = () => setPath(parse());
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  return { path, go: (to: string) => { window.location.hash = to; } };
}

export function usePersistentState<T>(key: string, initial: T): [T, (v: T | ((p: T) => T)) => void] {
  const [v, setV] = useState<T>(() => {
    try {
      const raw = window.localStorage.getItem(key);
      return raw ? { ...initial, ...JSON.parse(raw) } : initial;
    } catch { return initial; }
  });
  useEffect(() => {
    try { window.localStorage.setItem(key, JSON.stringify(v)); } catch { /* armazenamento indisponível */ }
  }, [key, v]);
  return [v, setV];
}
