import { EMBEDDED, api } from './api';

/** Salva um arquivo: no celular abre o menu de compartilhar; no computador, baixa. */
export async function saveFile(filename: string, content: string | Uint8Array, mime: string) {
  if (EMBEDDED) {
    const { Capacitor } = await import('@capacitor/core');
    if (Capacitor.isNativePlatform()) {
      const { Filesystem, Directory, Encoding } = await import('@capacitor/filesystem');
      const { Share } = await import('@capacitor/share');
      const { toBase64 } = await import('../../mobile/bytes');
      const res = typeof content === 'string'
        ? await Filesystem.writeFile({ path: filename, data: content, directory: Directory.Cache, encoding: Encoding.UTF8 })
        : await Filesystem.writeFile({ path: filename, data: toBase64(content), directory: Directory.Cache });
      await Share.share({ title: filename, url: res.uri, dialogTitle: 'Salvar ou enviar backup' });
      return;
    }
  }
  const blob = new Blob([content as BlobPart], { type: mime });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
}

export async function exportCollection(kind: 'json' | 'csv' | 'db') {
  const day = new Date().toISOString().slice(0, 10);
  if (kind === 'db') {
    const { localBackend } = await import('./api');
    const b = await localBackend();
    return saveFile(`ludoteca-${day}.db`, b.exportDb(), 'application/x-sqlite3');
  }
  const data = await api.exportData(kind);
  return kind === 'json'
    ? saveFile(`ludoteca-${day}.json`, JSON.stringify(data, null, 1), 'application/json')
    : saveFile(`ludoteca-${day}.csv`, data as string, 'text/csv');
}
