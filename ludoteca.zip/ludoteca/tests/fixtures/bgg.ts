/**
 * Fixtures no formato da XML API2 do BGG, para testes e para o servidor BGG simulado.
 * ATENÇÃO: os números (votos, pesos, IDs de expansões etc.) são ilustrativos — servem
 * para exercitar o código, não são dados reais do BoardGameGeek.
 */
export interface FixtureThing {
  id: number;
  type: 'boardgame' | 'boardgameexpansion';
  name: string;
  alt?: string[];
  year?: number;
  min?: number; max?: number;
  time?: number; minTime?: number; maxTime?: number;
  age?: number;
  poll?: [string, number, number, number][]; // numplayers, best, rec, notrec
  bestSummary?: string; recSummary?: string;
  links?: [string, number, string, boolean?][]; // type, id, value, inbound
  weight?: number; numWeights?: number;
  usersRated?: number; average?: number; rank?: number;
  families?: [string, string, number][]; // name, friendlyname, value
  versions?: { id: number; name: string; year?: number; lang: string; publisher: string }[];
  description?: string;
}

const esc = (s: string) => s.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

export function thingXml(things: FixtureThing[], opts: { versions?: boolean; imageBase?: string } = {}): string {
  const img = opts.imageBase ?? 'https://cf.geekdo-images.com/test';
  const items = things.map((t) => {
    const poll = t.poll ?? [];
    const total = poll.length ? Math.max(...poll.map((p) => p[1] + p[2] + p[3])) : 0;
    return `  <item type="${t.type}" id="${t.id}">
    <thumbnail>${img}/__thumb/img/${t.id}.jpg</thumbnail>
    <image>${img}/__original/img/${t.id}.jpg</image>
    <name type="primary" sortindex="1" value="${esc(t.name)}" />
${(t.alt ?? []).map((a) => `    <name type="alternate" sortindex="1" value="${esc(a)}" />`).join('\n')}
    <description>${esc(t.description ?? `Descrição de ${t.name}.&#10;&#10;Segunda linha.`).replace(/&amp;#10;/g, '&#10;')}</description>
    <yearpublished value="${t.year ?? 0}" />
    <minplayers value="${t.min ?? 0}" />
    <maxplayers value="${t.max ?? 0}" />
    <poll name="suggested_numplayers" title="User Suggested Number of Players" totalvotes="${total}">
${poll.map(([n, b, r, nr]) => `      <results numplayers="${n}">
        <result value="Best" numvotes="${b}" />
        <result value="Recommended" numvotes="${r}" />
        <result value="Not Recommended" numvotes="${nr}" />
      </results>`).join('\n')}
    </poll>
    <poll-summary name="suggested_numplayers" title="User Suggested Number of Players">
      <result name="bestwith" value="${esc(t.bestSummary ?? '')}" />
      <result name="recommmendedwith" value="${esc(t.recSummary ?? '')}" />
    </poll-summary>
    <poll name="suggested_playerage" title="User Suggested Player Age" totalvotes="0"></poll>
    <playingtime value="${t.time ?? 0}" />
    <minplaytime value="${t.minTime ?? t.time ?? 0}" />
    <maxplaytime value="${t.maxTime ?? t.time ?? 0}" />
    <minage value="${t.age ?? 0}" />
${(t.links ?? []).map(([type, id, value, inbound]) => `    <link type="${type}" id="${id}" value="${esc(value)}"${inbound ? ' inbound="true"' : ''} />`).join('\n')}
${opts.versions ? `    <versions>
${(t.versions ?? []).map((v) => `      <item type="boardgameversion" id="${v.id}">
        <thumbnail>https://cf.geekdo-images.com/v/${v.id}.jpg</thumbnail>
        <image>https://cf.geekdo-images.com/v/${v.id}-big.jpg</image>
        <link type="boardgameversion" id="${t.id}" value="${esc(t.name)}" inbound="true"/>
        <name type="primary" sortindex="1" value="${esc(v.name)}" />
        <link type="boardgamepublisher" id="1" value="${esc(v.publisher)}" />
        <yearpublished value="${v.year ?? 0}" />
        <link type="language" id="2" value="${esc(v.lang)}" />
      </item>`).join('\n')}
    </versions>` : ''}
    <statistics page="1">
      <ratings>
        <usersrated value="${t.usersRated ?? 0}" />
        <average value="${t.average ?? 0}" />
        <bayesaverage value="0" />
        <ranks>
          <rank type="subtype" id="1" name="boardgame" friendlyname="Board Game Rank" value="${t.rank ?? 'Not Ranked'}" bayesaverage="0" />
${(t.families ?? []).map(([n, f, v]) => `          <rank type="family" id="5" name="${n}" friendlyname="${f}" value="${v}" bayesaverage="0" />`).join('\n')}
        </ranks>
        <stddev value="0" /><median value="0" /><owned value="0" /><trading value="0" /><wanting value="0" /><wishing value="0" /><numcomments value="0" />
        <numweights value="${t.numWeights ?? 0}" />
        <averageweight value="${t.weight ?? 0}" />
      </ratings>
    </statistics>
  </item>`;
  });
  return `<?xml version="1.0" encoding="utf-8"?>\n<items termsofuse="https://boardgamegeek.com/xmlapi/termsofuse">\n${items.join('\n')}\n</items>`;
}

export function searchXml(items: { id: number; type: string; name: string; nameType?: string; year?: number }[]): string {
  return `<?xml version="1.0" encoding="utf-8"?>
<items total="${items.length}" termsofuse="https://boardgamegeek.com/xmlapi/termsofuse">
${items.map((i) => `  <item type="${i.type}" id="${i.id}">
    <name type="${i.nameType ?? 'primary'}" value="${esc(i.name)}"/>
    ${i.year ? `<yearpublished value="${i.year}" />` : ''}
  </item>`).join('\n')}
</items>`;
}

export const THINGS: FixtureThing[] = [
  {
    id: 13, type: 'boardgame', name: 'CATAN', alt: ['Catan', 'Colonizadores de Catan', 'Die Siedler von Catan'], year: 1995,
    min: 3, max: 4, time: 120, minTime: 60, maxTime: 120, age: 10,
    poll: [['1', 2, 10, 500], ['2', 5, 40, 480], ['3', 120, 380, 60], ['4', 520, 150, 10], ['4+', 20, 90, 300]],
    bestSummary: 'Best with 4 players', recSummary: 'Recommended with 3–4 players',
    links: [
      ['boardgamecategory', 1021, 'Economic'], ['boardgamecategory', 1026, 'Negotiation'],
      ['boardgamemechanic', 2072, 'Dice Rolling'], ['boardgamemechanic', 2081, 'Network and Route Building'],
      ['boardgamemechanic', 2008, 'Trading'], ['boardgamemechanic', 2002, 'Tile Placement'],
      ['boardgamefamily', 3, 'Catan'], ['boardgamedesigner', 11, 'Klaus Teuber'],
      ['boardgamepublisher', 37, 'KOSMOS'], ['boardgamepublisher', 9001, 'Devir'],
      ['boardgameexpansion', 926, 'CATAN: Cities & Knights'], ['boardgameexpansion', 325, 'CATAN: Seafarers'],
      ['boardgameexpansion', 99001, 'CATAN: Promo Harbor Tile'], ['boardgameexpansion', 99002, 'CATAN: Fan Scenario Pack'],
      ['boardgameexpansion', 99003, 'CATAN: Standalone Junior Edition'],
      ['boardgameimplementation', 27710, 'Catan Dice Game'],
    ],
    weight: 2.28, numWeights: 7000, usersRated: 110000, average: 7.1, rank: 550,
    families: [['strategygames', 'Strategy Game Rank', 400], ['familygames', 'Family Game Rank', 110]],
    versions: [
      { id: 501, name: 'Brazilian edition', year: 2012, lang: 'Portuguese', publisher: 'Devir' },
      { id: 502, name: 'English fifth edition', year: 2015, lang: 'English', publisher: 'Catan Studio' },
    ],
  },
  {
    id: 926, type: 'boardgameexpansion', name: 'CATAN: Cities & Knights', year: 1998, min: 3, max: 4, time: 90,
    links: [['boardgamecategory', 1042, 'Expansion for Base-game'], ['boardgamemechanic', 2072, 'Dice Rolling'], ['boardgameexpansion', 13, 'CATAN', true], ['boardgamepublisher', 37, 'KOSMOS']],
    weight: 2.9, numWeights: 1500, usersRated: 20000,
  },
  {
    id: 325, type: 'boardgameexpansion', name: 'CATAN: Seafarers', year: 1997, min: 3, max: 4, time: 90,
    links: [['boardgamecategory', 1042, 'Expansion for Base-game'], ['boardgameexpansion', 13, 'CATAN', true]],
    weight: 2.4, numWeights: 1000, usersRated: 15000,
  },
  {
    id: 99001, type: 'boardgameexpansion', name: 'CATAN: Promo Harbor Tile', year: 2015,
    links: [['boardgamecategory', 1042, 'Expansion for Base-game'], ['boardgamefamily', 7, 'Promotional: Promo tiles'], ['boardgameexpansion', 13, 'CATAN', true]],
  },
  {
    id: 99002, type: 'boardgameexpansion', name: 'CATAN: Fan Scenario Pack', year: 2010,
    links: [['boardgamecategory', 2687, 'Fan Expansion'], ['boardgameexpansion', 13, 'CATAN', true]],
  },
  {
    id: 99003, type: 'boardgame', name: 'CATAN: Standalone Junior Edition', year: 2007, min: 2, max: 4, time: 30,
    links: [['boardgamecategory', 1041, "Children's Game"], ['boardgameexpansion', 13, 'CATAN', true]],
    weight: 1.2, numWeights: 50,
  },
  {
    id: 30549, type: 'boardgame', name: 'Pandemic', alt: ['Pandemia'], year: 2008, min: 2, max: 4, time: 45, age: 8,
    poll: [['1', 1, 20, 300], ['2', 300, 600, 30], ['3', 250, 650, 40], ['4', 500, 400, 50], ['4+', 5, 20, 400]],
    bestSummary: 'Best with 4 players', recSummary: 'Recommended with 2–4 players',
    links: [
      ['boardgamecategory', 2145, 'Medical'], ['boardgamemechanic', 2023, 'Cooperative Game'],
      ['boardgamemechanic', 2040, 'Hand Management'], ['boardgamemechanic', 2015, 'Variable Player Powers'],
      ['boardgamemechanic', 2004, 'Set Collection'], ['boardgamedesigner', 442, 'Matt Leacock'],
      ['boardgamepublisher', 538, 'Z-Man Games'], ['boardgameexpansion', 40849, 'Pandemic: On the Brink'],
    ],
    weight: 2.4, numWeights: 5000, usersRated: 120000, average: 7.6, rank: 120,
    families: [['strategygames', 'Strategy Game Rank', 150], ['familygames', 'Family Game Rank', 20]],
    versions: [{ id: 601, name: 'Edição brasileira', year: 2011, lang: 'Portuguese', publisher: 'Devir' }],
  },
  {
    id: 40849, type: 'boardgameexpansion', name: 'Pandemic: On the Brink', year: 2009, min: 2, max: 5, time: 45,
    links: [['boardgamemechanic', 2023, 'Cooperative Game'], ['boardgameexpansion', 30549, 'Pandemic', true]],
    weight: 2.5, numWeights: 600,
  },
  {
    id: 266192, type: 'boardgame', name: 'Wingspan', year: 2019, min: 1, max: 5, time: 70, minTime: 40, maxTime: 70, age: 10,
    poll: [['1', 80, 400, 200], ['2', 300, 500, 60], ['3', 450, 350, 20], ['4', 200, 450, 80], ['5', 40, 250, 350], ['5+', 1, 5, 200]],
    bestSummary: 'Best with 3 players', recSummary: 'Recommended with 1–5 players',
    links: [
      ['boardgamecategory', 1089, 'Animals'], ['boardgamecategory', 1002, 'Card Game'],
      ['boardgamemechanic', 2040, 'Hand Management'], ['boardgamemechanic', 2004, 'Set Collection'],
      ['boardgamemechanic', 2819, 'Solo / Solitaire Game'], ['boardgamemechanic', 2072, 'Dice Rolling'],
      ['boardgamemechanic', 2874, 'Engine Building'],
      ['boardgamedesigner', 1, 'Elizabeth Hargrave'], ['boardgamepublisher', 2, 'Stonemaier Games'],
    ],
    weight: 2.45, numWeights: 3000, usersRated: 90000, average: 8.0, rank: 30,
    families: [['strategygames', 'Strategy Game Rank', 25]],
  },
  {
    id: 400000, type: 'boardgame', name: 'Obscure Prototype', year: 2024, min: 2, max: 6, time: 0,
    links: [['boardgamedesigner', 3, 'Someone']],
  },
];

export const SEARCH: Record<string, { id: number; type: string; name: string; nameType?: string; year?: number }[]> = {
  catan: [
    { id: 13, type: 'boardgame', name: 'CATAN', year: 1995 },
    { id: 926, type: 'boardgameexpansion', name: 'CATAN: Cities & Knights', year: 1998 },
    { id: 325, type: 'boardgameexpansion', name: 'CATAN: Seafarers', year: 1997 },
  ],
  'colonizadores de catan': [{ id: 13, type: 'boardgame', name: 'Colonizadores de Catan', nameType: 'alternate', year: 1995 }],
  pandemic: [
    { id: 30549, type: 'boardgame', name: 'Pandemic', year: 2008 },
    { id: 40849, type: 'boardgameexpansion', name: 'Pandemic: On the Brink', year: 2009 },
  ],
  pandemia: [{ id: 30549, type: 'boardgame', name: 'Pandemia', nameType: 'alternate', year: 2008 }],
  wingspan: [{ id: 266192, type: 'boardgame', name: 'Wingspan', year: 2019 }],
  'cities knights': [{ id: 926, type: 'boardgameexpansion', name: 'CATAN: Cities & Knights', year: 1998 }],
  'catan cities knights': [{ id: 926, type: 'boardgameexpansion', name: 'CATAN: Cities & Knights', year: 1998 }],
};

/** fetch simulado do BGG (exige token, como a API real). */
export function fakeBggFetch(opts: { token?: string; failTimes?: number; status?: number; log?: string[] } = {}): typeof fetch {
  let failures = opts.failTimes ?? 0;
  return (async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = new URL(String(input));
    opts.log?.push(url.pathname + url.search);
    const auth = new Headers(init?.headers).get('authorization');
    if (auth !== `Bearer ${opts.token ?? 'test-token'}`) return new Response('Unauthorized', { status: 401 });
    if (failures > 0) { failures--; return new Response('busy', { status: opts.status ?? 503 }); }
    if (url.pathname.endsWith('/xmlapi2/thing')) {
      const ids = (url.searchParams.get('id') ?? '').split(',').map(Number);
      const found = THINGS.filter((t) => ids.includes(t.id));
      return new Response(thingXml(found, { versions: url.searchParams.get('versions') === '1' }), { status: 200, headers: { 'content-type': 'text/xml' } });
    }
    if (url.pathname.endsWith('/xmlapi2/search')) {
      const q = (url.searchParams.get('query') ?? '').toLowerCase().replace(/[^a-z0-9 ]/g, '').replace(/\s+/g, ' ').trim();
      return new Response(searchXml(SEARCH[q] ?? []), { status: 200 });
    }
    return new Response('not found', { status: 404 });
  }) as typeof fetch;
}
