import { describe, expect, it } from 'vitest';
import { parseSearch, parseThings, xmlErrorMessage } from '../../src/server/bgg/parse';
import { computeBestWith, deriveTags, inferExpansionType, portugueseVersions, relationsOf } from '../../src/server/bgg/derive';
import { durationBucket } from '../../src/shared/domain';
import { BggClient, BggError } from '../../src/server/bgg/client';
import { openDb } from '../../src/server/db';
import { THINGS, fakeBggFetch, searchXml, thingXml } from '../fixtures/bgg';
import { similarity } from '../../src/server/services/bggService';

const catan = () => parseThings(thingXml([THINGS[0]], { versions: true }))[0];

describe('parser da XML API2', () => {
  it('lê campos oficiais, enquete e estatísticas', () => {
    const t = catan();
    expect(t.id).toBe(13);
    expect(t.primaryName).toBe('CATAN');
    expect(t.altNames).toContain('Colonizadores de Catan');
    expect(t.minPlayers).toBe(3);
    expect(t.maxPlayers).toBe(4);
    expect(t.minPlaytime).toBe(60);
    expect(t.maxPlaytime).toBe(120);
    expect(t.stats?.weight).toBeCloseTo(2.28);
    expect(t.stats?.numWeights).toBe(7000);
    expect(t.stats?.rank).toBe(550);
    expect(t.poll).toHaveLength(5);
    expect(t.poll.find((p) => p.numPlayers === '4')).toEqual({ numPlayers: '4', best: 520, recommended: 150, notRecommended: 10 });
    expect(t.pollSummaryBest).toBe('Best with 4 players');
    expect(t.description).toContain('\n');
    expect(t.versions?.length).toBe(2);
  });

  it('trata zeros do BGG como ausentes e "Not Ranked" como null', () => {
    const t = parseThings(thingXml([THINGS.find((x) => x.id === 400000)!]))[0];
    expect(t.playingTime).toBeNull();
    expect(t.stats?.rank).toBeNull();
    expect(t.poll.every((p) => p.best === 0)).toBe(true);
  });

  it('lê resultados de busca com nome alternativo', () => {
    const r = parseSearch(searchXml([{ id: 13, type: 'boardgame', name: 'Colonizadores de Catan', nameType: 'alternate', year: 1995 }]));
    expect(r).toEqual([{ id: 13, type: 'boardgame', name: 'Colonizadores de Catan', nameType: 'alternate', year: 1995 }]);
  });

  it('detecta mensagens de erro em XML', () => {
    expect(xmlErrorMessage('<errors><error><message>Rate limit exceeded.</message></error></errors>')).toBe('Rate limit exceeded.');
    expect(xmlErrorMessage('<items></items>')).toBeNull();
  });
});

describe('Best With (comunidade)', () => {
  it('ordena por votos "Best" e ignora contagens N+', () => {
    const b = computeBestWith(catan().poll);
    expect(b.first).toEqual({ count: '4', votes: 520 });
    expect(b.second).toEqual({ count: '3', votes: 120 });
    expect(b.recommended).toEqual([3, 4]);
  });

  it('sem votos não inventa recomendação', () => {
    const b = computeBestWith([{ numPlayers: '2', best: 0, recommended: 0, notRecommended: 0 }]);
    expect(b.first).toBeNull();
    expect(b.second).toBeNull();
    expect(b.recommended).toEqual([]);
  });

  it('desempata pelo total Best + Recommended', () => {
    const b = computeBestWith([
      { numPlayers: '2', best: 10, recommended: 5, notRecommended: 0 },
      { numPlayers: '3', best: 10, recommended: 20, notRecommended: 0 },
    ]);
    expect(b.first?.count).toBe('3');
  });
});

describe('etiquetas derivadas', () => {
  const bucket = (m: number | null) => durationBucket(m);
  it('usa só mecânicas/categorias oficiais e marca inferências', () => {
    const tags = deriveTags(catan(), 120, bucket);
    const byName = new Map(tags.map((t) => [t.name, t]));
    expect(byName.get('Dice rolling')?.source).toBe('bgg_derived');
    expect(byName.get('Route building')?.source).toBe('bgg_derived');
    expect(byName.get('Econômico')?.source).toBe('bgg_derived');
    expect(byName.get('Estratégico')?.detail).toContain('Strategy Game Rank');
    expect(byName.get('Competitivo')?.source).toBe('inferred');
    expect(byName.get('Duração longa')?.source).toBe('inferred');
    expect(byName.has('Cooperativo')).toBe(false);
  });

  it('cooperativo apenas com a mecânica "Cooperative Game"', () => {
    const pandemic = parseThings(thingXml([THINGS.find((t) => t.id === 30549)!]))[0];
    const tags = deriveTags(pandemic, 45, bucket).map((t) => t.name);
    expect(tags).toContain('Cooperativo');
    expect(tags).toContain('Cooperative play');
    expect(tags).not.toContain('Competitivo');
    // "Variable Player Powers" e "Hand Management" aparecem em cooperativos, mas não bastam
    const wingspan = parseThings(thingXml([THINGS.find((t) => t.id === 266192)!]))[0];
    const wt = deriveTags(wingspan, 70, bucket).map((t) => t.name);
    expect(wt).not.toContain('Cooperativo');
    expect(wt).toContain('Solo');
    expect(wt).toContain('Engine building');
    expect(wt).toContain('Presença de cartas');
  });
});

describe('expansões e relações', () => {
  it('separa expansões, implementações e jogos independentes', () => {
    const r = relationsOf(catan());
    expect(r.expansions.map((e) => e.id)).toEqual([926, 325, 99001, 99002, 99003]);
    expect(r.implementations.map((e) => e.id)).toEqual([27710]);
    const exp = parseThings(thingXml([THINGS.find((t) => t.id === 926)!]))[0];
    expect(relationsOf(exp).bases.map((b) => b.id)).toEqual([13]);
    const standalone = parseThings(thingXml([THINGS.find((t) => t.id === 99003)!]))[0];
    expect(relationsOf(standalone).standaloneExpansion).toBe(true);
  });

  it('identifica promos e expansões de fãs', () => {
    const promo = parseThings(thingXml([THINGS.find((t) => t.id === 99001)!]))[0];
    const fan = parseThings(thingXml([THINGS.find((t) => t.id === 99002)!]))[0];
    expect(inferExpansionType(promo)).toBe('promo');
    expect(inferExpansionType(fan)).toBe('fan');
  });

  it('lista edições em português sem confundir com o título', () => {
    expect(portugueseVersions(catan())).toEqual([{ name: 'Brazilian edition', publisher: 'Devir', year: 2012 }]);
  });
});

describe('cliente do BGG', () => {
  it('exige token e não faz requisição sem ele', async () => {
    const db = openDb(':memory:');
    const log: string[] = [];
    const c = new BggClient({ db, token: null, baseUrl: 'https://boardgamegeek.com', minIntervalMs: 1, cacheTtlHours: 1, fetchImpl: fakeBggFetch({ log }) });
    await expect(c.search('catan')).rejects.toMatchObject({ code: 'not_configured' });
    expect(log).toHaveLength(0);
  });

  it('envia Bearer token, usa cache e respeita repetição em 503', async () => {
    const db = openDb(':memory:');
    const log: string[] = [];
    const sleeps: number[] = [];
    const c = new BggClient({
      db, token: 'test-token', baseUrl: 'https://boardgamegeek.com', minIntervalMs: 10, cacheTtlHours: 1,
      fetchImpl: fakeBggFetch({ log, failTimes: 2 }), sleep: async (ms) => { sleeps.push(ms); },
    });
    const r = await c.search('catan');
    expect(r[0].id).toBe(13);
    expect(log).toHaveLength(3); // 2 falhas + sucesso
    await c.search('catan');
    expect(log).toHaveLength(3); // veio do cache
    expect(sleeps.length).toBeGreaterThanOrEqual(2);
  });

  it('token inválido gera erro de autenticação claro', async () => {
    const db = openDb(':memory:');
    const c = new BggClient({ db, token: 'errado', baseUrl: 'https://boardgamegeek.com', minIntervalMs: 1, cacheTtlHours: 1, fetchImpl: fakeBggFetch() });
    const err = await c.thing(13).catch((e) => e);
    expect(err).toBeInstanceOf(BggError);
    expect(err.code).toBe('auth');
  });

  it('busca em lotes de no máximo 20 IDs', async () => {
    const db = openDb(':memory:');
    const log: string[] = [];
    const c = new BggClient({ db, token: 'test-token', baseUrl: 'https://boardgamegeek.com', minIntervalMs: 1, cacheTtlHours: 1, fetchImpl: fakeBggFetch({ log }) });
    await c.things(Array.from({ length: 45 }, (_, i) => i + 1));
    expect(log.filter((l) => l.includes('/thing'))).toHaveLength(3);
  });

  it('usa cache antigo quando o BGG está fora do ar', async () => {
    const db = openDb(':memory:');
    const ok = new BggClient({ db, token: 'test-token', baseUrl: 'https://x', minIntervalMs: 1, cacheTtlHours: 1, fetchImpl: fakeBggFetch() });
    await ok.thing(13);
    const down = new BggClient({
      db, token: 'test-token', baseUrl: 'https://x', minIntervalMs: 1, cacheTtlHours: 1, maxRetries: 1,
      fetchImpl: fakeBggFetch({ failTimes: 99 }), sleep: async () => {},
    });
    const t = await down.thing(13, { force: true });
    expect(t?.primaryName).toBe('CATAN');
  });
});

describe('similaridade de títulos', () => {
  it('reconhece títulos iguais com acentos/pontuação diferentes', () => {
    expect(similarity('Catan', 'CATAN')).toBe(1);
    expect(similarity('Cities and Knights', 'Cities & Knights')).toBe(1);
    expect(similarity('Pandemia', 'Pandemic')).toBeGreaterThan(0.7);
    expect(similarity('Azul', 'Wingspan')).toBeLessThan(0.4);
  });
});
