import { test, expect, type Page } from '@playwright/test';

/** App de celular: banco no aparelho, coleção inicial, token, vínculo em lote, adicionar jogo, persistência. */
test.describe.serial('app de celular', () => {
  let page: Page;
  test.beforeAll(async ({ browser }) => {
    page = await browser.newPage({ viewport: { width: 412, height: 915 }, isMobile: true, hasTouch: true });
    page.on('pageerror', (e) => { throw e; });
  });

  test('abre já com a coleção das fotos', async () => {
    await page.goto('/');
    await expect(page.getByRole('button', { name: 'Abrir Azul Mini' })).toBeVisible({ timeout: 30_000 });
    await expect(page.getByRole('navigation', { name: 'Navegação' })).toBeVisible();
    await page.screenshot({ path: 'test-results/mobile-1-library.png' });
  });

  test('filtra os jogos do Arthur Bunte e mostra onde estão', async () => {
    await page.getByRole('button', { name: /Filtros/ }).click();
    await page.locator('.sidebar').getByRole('button', { name: /Arthur Bunte/ }).click();
    await page.locator('.sidebar').getByRole('button', { name: 'Fechar filtros' }).click();
    await expect(page.locator('.toolbar .count b')).toHaveText('17');
    await expect(page.getByRole('button', { name: 'Abrir Spirit Island' })).toBeVisible();
    await expect(page.getByText('não está comigo')).toHaveCount(0);
    await page.getByRole('button', { name: /Limpar filtros/ }).click();
  });

  test('salva o token do BGG nas configurações do aparelho', async () => {
    await page.getByRole('navigation', { name: 'Navegação' }).getByRole('link', { name: /Configurações/ }).click();
    await page.getByLabel('Token do BGG').fill('dev-token');
    await page.locator('.card-panel', { hasText: 'BoardGameGeek' }).getByRole('button', { name: 'Salvar' }).click();
    await expect(page.getByText(/Token configurado/)).toBeVisible();
  });

  test('adiciona um jogo novo pelo botão +', async () => {
    await page.getByRole('navigation', { name: 'Navegação' }).getByRole('link', { name: /Biblioteca/ }).click();
    await page.getByRole('button', { name: 'Adicionar jogo' }).last().click();
    await page.getByLabel('Nome do jogo').fill('Catan');
    await page.getByRole('button', { name: 'Buscar', exact: true }).click();
    await page.getByRole('option', { name: /CATAN \(1995\)/ }).click();
    await page.getByRole('button', { name: 'Adicionar à coleção' }).click();
    await expect(page.getByRole('dialog', { name: 'CATAN' }).getByText('Melhor 4 e 3')).toBeVisible();
    await page.getByRole('dialog', { name: 'CATAN' }).getByRole('button', { name: 'Fechar' }).click();
  });

  test('vincula a coleção ao BGG em lote, com revisão', async () => {
    await page.getByRole('button', { name: 'Vincular ao BGG' }).click();
    await expect(page.getByRole('heading', { name: 'Vincular jogos ao BGG' })).toBeVisible();
    await expect(page.getByText(/Buscando no BGG/)).toHaveCount(0, { timeout: 180_000 });
    const wing = page.locator('.cand', { has: page.locator('input[value="Wingspan"]') });
    await expect(wing.getByRole('radio', { name: /Wingspan \(2019\)/ })).toHaveAttribute('aria-checked', 'true');
    await wing.getByRole('button', { name: 'Confirmar' }).click();
    await page.screenshot({ path: 'test-results/mobile-2-link.png' });
    await page.getByRole('button', { name: /Vincular 1/ }).click();
    await expect(page.getByText(/1 jogo\(s\) vinculado/)).toBeVisible();
  });

  test('dados continuam no aparelho depois de fechar e abrir o app', async () => {
    await page.waitForTimeout(800); // gravação agrupada
    await page.goto('/');
    await page.reload();
    await expect(page.getByRole('button', { name: 'Abrir Wingspan' }).first()).toBeVisible({ timeout: 30_000 });
    await page.getByLabel('Pesquisar na coleção').fill('wingspan');
    await page.getByRole('button', { name: 'Abrir Wingspan' }).first().click();
    await expect(page.getByRole('dialog', { name: 'Wingspan' }).getByText('Melhor 3 e 2')).toBeVisible();
    await page.screenshot({ path: 'test-results/mobile-3-detail.png' });
  });
});
