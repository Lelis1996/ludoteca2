import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'br.ludoteca.app',
  appName: 'Ludoteca',
  webDir: 'dist/mobile',
  android: { backgroundColor: '#15120f' },
  plugins: {
    // requisições pela camada nativa: permite falar direto com o BGG e a Anthropic (sem CORS)
    CapacitorHttp: { enabled: true },
  },
};

export default config;
