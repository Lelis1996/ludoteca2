import { defineConfig, devices } from '@playwright/test';

// Testa o app de celular (backend embutido) num navegador com tela de celular, contra o BGG simulado.
export default defineConfig({
  testDir: 'tests/e2e-mobile',
  timeout: 240_000,
  workers: 1,
  reporter: [['list']],
  use: { ...devices['Pixel 7'], baseURL: 'http://127.0.0.1:4174', screenshot: 'only-on-failure' },
  webServer: [
    { command: 'npx tsx scripts/fake-bgg.ts', env: { FAKE_BGG_PORT: '5997' }, url: 'http://127.0.0.1:5997/xmlapi2/none', reuseExistingServer: false, timeout: 30_000 },
    {
      command: 'npm run build:mobile && npx vite preview --mode mobile --port 4174 --strictPort --host 127.0.0.1',
      url: 'http://127.0.0.1:4174',
      reuseExistingServer: false,
      timeout: 240_000,
      env: { VITE_BGG_BASE_URL: 'http://127.0.0.1:5997', VITE_BGG_MIN_INTERVAL_MS: '50' },
    },
  ],
});
