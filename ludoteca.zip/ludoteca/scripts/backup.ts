/**
 * Backup completo: cópia consistente do banco SQLite + exportação JSON.
 *   npm run backup                 → data/backups/
 *   npm run backup -- /outra/pasta → pasta escolhida
 * Pode ser executado com a aplicação rodando.
 */
import fs from 'node:fs';
import path from 'node:path';
import { loadConfig } from '../src/server/config';
import { openDb } from '../src/server/db';
import { exportJson } from '../src/server/services/backup';

const config = loadConfig();
const outDir = path.resolve(process.argv[2] || path.join(config.dataDir, 'backups'));
fs.mkdirSync(outDir, { recursive: true });
const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
const db = openDb(config.dbPath);
const dbFile = path.join(outDir, `ludoteca-${stamp}.db`);
await db.raw.backup(dbFile);
const jsonFile = path.join(outDir, `ludoteca-${stamp}.json`);
fs.writeFileSync(jsonFile, JSON.stringify(exportJson(db), null, 1));
const n = (db.prepare('SELECT COUNT(*) n FROM games').get() as { n: number }).n;
db.close();
console.log(`Backup concluído (${n} itens):\n  ${dbFile}\n  ${jsonFile}`);
