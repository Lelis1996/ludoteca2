/**
 * Servidor que imita a XML API2 do BGG com dados ILUSTRATIVOS (tests/fixtures/bgg.ts).
 * Serve para desenvolver e testar sem token. NÃO use para a sua coleção real.
 *   npm run fake-bgg   →  http://127.0.0.1:5999  (token: dev-token)
 * Depois rode a aplicação com BGG_BASE_URL=http://127.0.0.1:5999 BGG_API_TOKEN=dev-token
 */
import http from 'node:http';
import sharp from 'sharp';
import { SEARCH, THINGS, searchXml, thingXml } from '../tests/fixtures/bgg';

const port = Number(process.env.FAKE_BGG_PORT || 5999);
const base = `http://127.0.0.1:${port}`;
const colors = ['#8b5cf6', '#ef4444', '#10b981', '#f59e0b', '#3b82f6', '#ec4899', '#14b8a6'];

http.createServer(async (req, res) => {
  const url = new URL(req.url ?? '/', base);
  // CORS: permite testar o app de celular no navegador
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type');
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }
  if (url.pathname.includes('/img/')) {
    const id = Number(url.pathname.match(/(\d+)\.jpg$/)?.[1] ?? 0);
    const t = THINGS.find((x) => x.id === id);
    const color = colors[id % colors.length];
    const label = (t?.name ?? `#${id}`).replace(/&/g, '&amp;').replace(/</g, '&lt;');
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="400"><rect width="400" height="400" fill="${color}"/><rect x="20" y="20" width="360" height="360" fill="none" stroke="#fff" stroke-opacity=".4" stroke-width="4"/><text x="200" y="210" font-family="DejaVu Sans, sans-serif" font-size="30" font-weight="bold" fill="#fff" text-anchor="middle">${label.slice(0, 22)}</text><text x="200" y="250" font-family="DejaVu Sans" font-size="18" fill="#fff" fill-opacity=".8" text-anchor="middle">${label.slice(22, 44)}</text></svg>`;
    res.writeHead(200, { 'content-type': 'image/jpeg' });
    return res.end(await sharp(Buffer.from(svg)).jpeg().toBuffer());
  }
  if (req.headers.authorization !== 'Bearer dev-token') { res.writeHead(401); return res.end('Unauthorized'); }
  if (url.pathname === '/xmlapi2/thing') {
    const ids = (url.searchParams.get('id') ?? '').split(',').map(Number);
    res.writeHead(200, { 'content-type': 'text/xml' });
    return res.end(thingXml(THINGS.filter((t) => ids.includes(t.id)), { versions: url.searchParams.get('versions') === '1', imageBase: base }));
  }
  if (url.pathname === '/xmlapi2/search') {
    const q = (url.searchParams.get('query') ?? '').toLowerCase().replace(/[^a-z0-9 ]/g, '').replace(/\s+/g, ' ').trim();
    const items = SEARCH[q] ?? Object.values(SEARCH).flat().filter((i, idx, arr) => i.name.toLowerCase().includes(q) && arr.findIndex((x) => x.id === i.id) === idx);
    res.writeHead(200, { 'content-type': 'text/xml' });
    return res.end(searchXml(items));
  }
  res.writeHead(404); res.end();
}).listen(port, '127.0.0.1', () => console.log(`BGG simulado em ${base} (token: dev-token)`));
