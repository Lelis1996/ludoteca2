// Gera ícone e tela de abertura do app Android (já incluídos no projeto; rode de novo se mudar o visual).
import sharp from 'sharp';
import fs from 'node:fs';
import path from 'node:path';

const res = path.resolve('android/app/src/main/res');
const AMBER = '#e8a33d', INK = '#1d1407', BG = '#15120f';
const glyph = (size, color) => `<text x="50%" y="50%" dy="0.35em" text-anchor="middle" font-family="DejaVu Serif, Georgia, serif" font-weight="bold" font-size="${size}" fill="${color}">L</text>`;
const dens = { mdpi: 1, hdpi: 1.5, xhdpi: 2, xxhdpi: 3, xxxhdpi: 4 };

for (const [d, k] of Object.entries(dens)) {
  const s = Math.round(48 * k), f = Math.round(108 * k);
  const icon = `<svg xmlns="http://www.w3.org/2000/svg" width="${s}" height="${s}"><rect width="${s}" height="${s}" rx="${s * 0.22}" fill="${AMBER}"/>${glyph(s * 0.62, INK)}</svg>`;
  const round = `<svg xmlns="http://www.w3.org/2000/svg" width="${s}" height="${s}"><circle cx="${s / 2}" cy="${s / 2}" r="${s / 2}" fill="${AMBER}"/>${glyph(s * 0.58, INK)}</svg>`;
  const fg = `<svg xmlns="http://www.w3.org/2000/svg" width="${f}" height="${f}">${glyph(f * 0.42, INK)}</svg>`;
  await sharp(Buffer.from(icon)).png().toFile(path.join(res, `mipmap-${d}`, 'ic_launcher.png'));
  await sharp(Buffer.from(round)).png().toFile(path.join(res, `mipmap-${d}`, 'ic_launcher_round.png'));
  await sharp(Buffer.from(fg)).png().toFile(path.join(res, `mipmap-${d}`, 'ic_launcher_foreground.png'));
}
fs.writeFileSync(path.join(res, 'values/ic_launcher_background.xml'), `<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">${AMBER}</color>\n</resources>\n`);

for (const dir of fs.readdirSync(res).filter((x) => x.startsWith('drawable'))) {
  const file = path.join(res, dir, 'splash.png');
  if (!fs.existsSync(file)) continue;
  const { width, height } = await sharp(file).metadata();
  const m = Math.min(width, height) * 0.22;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}"><rect width="100%" height="100%" fill="${BG}"/>
    <rect x="${width / 2 - m / 2}" y="${height / 2 - m / 2 - m * 0.2}" width="${m}" height="${m}" rx="${m * 0.22}" fill="${AMBER}"/>
    <text x="${width / 2}" y="${height / 2 - m * 0.2}" dy="0.35em" text-anchor="middle" font-family="DejaVu Serif" font-weight="bold" font-size="${m * 0.62}" fill="${INK}">L</text>
    <text x="${width / 2}" y="${height / 2 + m * 0.75}" text-anchor="middle" font-family="DejaVu Serif" font-weight="bold" font-size="${m * 0.32}" fill="#f2ece2">Ludoteca</text></svg>`;
  await sharp(Buffer.from(svg)).png().toFile(file + '.tmp');
  fs.renameSync(file + '.tmp', file);
}
console.log('Ícones e splash gerados.');
